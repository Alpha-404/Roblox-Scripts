local sethid = sethiddenproperty or set_hidden_property or set_hidden_prop
local setsim = setsimulationradius or set_simulation_radius
local huge = math.huge*math.huge

while true do
    settings().Physics.AllowSleep = false
    settings().Physics.PhysicsEnvironmentalThrottle = Enum.EnviromentalPhysicsThrottle.Disabled
    game:GetService("Players").LocalPlayer.ReplicationFocus = workspace
    sethid(game:GetService("Players").LocalPlayer, "MaximumSimulationRadius",huge) 
    sethid(game:GetService("Players").LocalPlayer, "SimulationRadius", huge)
    setsim(huge,huge,huge,huge)
    game["Run Service"].Heartbeat:Wait()
end