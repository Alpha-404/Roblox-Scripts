if game:GetService("CoreGui"):FindFirstChild("Star Nebula") then
	game:GetService("CoreGui")["Star Nebula"]:Destroy()
end
local ver = "v1.4"

local StarNebula = Instance.new("ScreenGui")
local Shadow = Instance.new("Frame")
local Shadow_2 = Instance.new("Folder")
local Frame = Instance.new("Frame")
local mainFrame = Instance.new("ImageLabel")
local topbarFrame = Instance.new("ImageLabel")
local TextLabel = Instance.new("TextLabel")
local ScrollingFrame = Instance.new("ScrollingFrame")
local PlaceHolder = Instance.new("TextButton")
local UICorner = Instance.new("UICorner")
local UIListLayout = Instance.new("UIListLayout")
local russian = Instance.new("TextButton")
local UICorner_2 = Instance.new("UICorner")
local Crusin = Instance.new("TextButton")
local UICorner_3 = Instance.new("UICorner")
local Skibidi = Instance.new("TextButton")
local UICorner_4 = Instance.new("UICorner")
local AnthonyShuffle = Instance.new("TextButton")
local UICorner_5 = Instance.new("UICorner")
local AnthonyShuffle_2 = Instance.new("TextButton")
local UICorner_6 = Instance.new("UICorner")
local AnthonyShuffle_3 = Instance.new("TextButton")
local UICorner_7 = Instance.new("UICorner")
local AnthonyShuffle_4 = Instance.new("TextButton")
local UICorner_8 = Instance.new("UICorner")
local Chill = Instance.new("TextButton")
local UICorner_9 = Instance.new("UICorner")
local Smug = Instance.new("TextButton")
local UICorner_10 = Instance.new("UICorner")
local Dirty = Instance.new("TextButton")
local UICorner_11 = Instance.new("UICorner")

StarNebula.Name = "Star Nebula"
StarNebula.Parent = game:GetService("CoreGui")
StarNebula.ResetOnSpawn = false

Shadow.Name = "Shadow"
Shadow.Parent = StarNebula
Shadow.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Shadow.BackgroundTransparency = 1.000
Shadow.BorderSizePixel = 0
Shadow.Position = UDim2.new(0.616363645, -294, 0.598280072, -149)
Shadow.Size = UDim2.new(0, 267, 0, 170)

Shadow_2.Name = "Shadow"
Shadow_2.Parent = Shadow

Frame.Parent = Shadow_2
Frame.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Frame.BorderSizePixel = 0
Frame.Position = UDim2.new(0, -4, 0, -4)
Frame.Size = UDim2.new(1, 8, 1, 8)
Frame.Style = Enum.FrameStyle.DropShadow

mainFrame.Name = "mainFrame"
mainFrame.Parent = Shadow
mainFrame.BackgroundColor3 = Color3.fromRGB(32, 32, 32)
mainFrame.BackgroundTransparency = 1.000
mainFrame.BorderSizePixel = 0
mainFrame.ClipsDescendants = true
mainFrame.Position = UDim2.new(-0.000796778651, 0, -0.00258674752, 0)
mainFrame.Size = UDim2.new(0, 264, 0, 168)
mainFrame.Image = "http://www.roblox.com/asset/?id=4530318781"
mainFrame.ImageColor3 = Color3.fromRGB(32, 32, 32)
mainFrame.ScaleType = Enum.ScaleType.Slice
mainFrame.SliceCenter = Rect.new(20, 20, 480, 480)

topbarFrame.Name = "topbarFrame"
topbarFrame.Parent = mainFrame
topbarFrame.BackgroundColor3 = Color3.fromRGB(24, 24, 24)
topbarFrame.BackgroundTransparency = 1.000
topbarFrame.BorderSizePixel = 0
topbarFrame.Size = UDim2.new(0, 264, 0, 33)
topbarFrame.Image = "http://www.roblox.com/asset/?id=4530319192"
topbarFrame.ImageColor3 = Color3.fromRGB(24, 24, 24)
topbarFrame.ScaleType = Enum.ScaleType.Slice
topbarFrame.SliceCenter = Rect.new(20, 20, 480, 480)

TextLabel.Parent = topbarFrame
TextLabel.BackgroundColor3 = Color3.fromRGB(154, 154, 154)
TextLabel.BackgroundTransparency = 1.000
TextLabel.BorderSizePixel = 0
TextLabel.Position = UDim2.new(0.0679237992, 0, 0.24242425, 0)
TextLabel.Size = UDim2.new(0, 228, 0, 16)
TextLabel.Font = Enum.Font.SourceSans
TextLabel.Text = "Star Nebula  "..ver.."| Animation Hub"
TextLabel.TextColor3 = Color3.fromRGB(189, 189, 189)
TextLabel.TextSize = 12.000

ScrollingFrame.Parent = mainFrame
ScrollingFrame.Active = true
ScrollingFrame.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
ScrollingFrame.BackgroundTransparency = 1.000
ScrollingFrame.BorderSizePixel = 0
ScrollingFrame.Position = UDim2.new(0, 0, 0.202380955, 0)
ScrollingFrame.Size = UDim2.new(0, 264, 0, 134)
ScrollingFrame.CanvasSize = UDim2.new(0, 0, 1.5, 0)
ScrollingFrame.ScrollBarThickness = 0

PlaceHolder.Name = "PlaceHolder"
PlaceHolder.Parent = ScrollingFrame
PlaceHolder.BackgroundColor3 = Color3.fromRGB(24, 24, 24)
PlaceHolder.BackgroundTransparency = 1.000
PlaceHolder.Position = UDim2.new(0.0359848477, 0, 0, 0)
PlaceHolder.Size = UDim2.new(0, 245, 0, 13)
PlaceHolder.Font = Enum.Font.SourceSans
PlaceHolder.Text = ""
PlaceHolder.TextColor3 = Color3.fromRGB(255, 255, 255)
PlaceHolder.TextSize = 14.000

UICorner.Parent = PlaceHolder

UIListLayout.Parent = ScrollingFrame
UIListLayout.HorizontalAlignment = Enum.HorizontalAlignment.Center
UIListLayout.SortOrder = Enum.SortOrder.LayoutOrder
UIListLayout.Padding = UDim.new(0.00999999978, 0)

russian.Name = "russian"
russian.Parent = ScrollingFrame
russian.BackgroundColor3 = Color3.fromRGB(24, 24, 24)
russian.Position = UDim2.new(0.0303030312, 0, 0.795385838, 0)
russian.Size = UDim2.new(0, 245, 0, 21)
russian.Font = Enum.Font.SourceSans
russian.Text = "Russian Dance"
russian.TextColor3 = Color3.fromRGB(255, 255, 255)
russian.TextSize = 14.000

UICorner_2.Parent = russian

Crusin.Name = "Crusin"
Crusin.Parent = ScrollingFrame
Crusin.BackgroundColor3 = Color3.fromRGB(24, 24, 24)
Crusin.Position = UDim2.new(0.0303030312, 0, 0.795385838, 0)
Crusin.Size = UDim2.new(0, 245, 0, 21)
Crusin.Font = Enum.Font.SourceSans
Crusin.Text = "Crusin"
Crusin.TextColor3 = Color3.fromRGB(255, 255, 255)
Crusin.TextSize = 14.000

UICorner_3.Parent = Crusin

Skibidi.Name = "Skibidi"
Skibidi.Parent = ScrollingFrame
Skibidi.BackgroundColor3 = Color3.fromRGB(24, 24, 24)
Skibidi.Position = UDim2.new(0.0303030312, 0, 0.795385838, 0)
Skibidi.Size = UDim2.new(0, 245, 0, 21)
Skibidi.Font = Enum.Font.SourceSans
Skibidi.Text = "Skibidi"
Skibidi.TextColor3 = Color3.fromRGB(255, 255, 255)
Skibidi.TextSize = 14.000

UICorner_4.Parent = Skibidi

AnthonyShuffle.Name = "AnthonyShuffle"
AnthonyShuffle.Parent = ScrollingFrame
AnthonyShuffle.BackgroundColor3 = Color3.fromRGB(24, 24, 24)
AnthonyShuffle.Position = UDim2.new(0.0303030312, 0, 0.795385838, 0)
AnthonyShuffle.Size = UDim2.new(0, 245, 0, 21)
AnthonyShuffle.Font = Enum.Font.SourceSans
AnthonyShuffle.Text = "Anthony Shuffle"
AnthonyShuffle.TextColor3 = Color3.fromRGB(255, 255, 255)
AnthonyShuffle.TextSize = 14.000

UICorner_5.Parent = AnthonyShuffle

AnthonyShuffle_2.Name = "AnthonyShuffle"
AnthonyShuffle_2.Parent = ScrollingFrame
AnthonyShuffle_2.BackgroundColor3 = Color3.fromRGB(24, 24, 24)
AnthonyShuffle_2.Position = UDim2.new(0.0303030312, 0, 0.795385838, 0)
AnthonyShuffle_2.Size = UDim2.new(0, 245, 0, 21)
AnthonyShuffle_2.Font = Enum.Font.SourceSans
AnthonyShuffle_2.Text = "Boogie Down"
AnthonyShuffle_2.TextColor3 = Color3.fromRGB(255, 255, 255)
AnthonyShuffle_2.TextSize = 14.000

UICorner_6.Parent = AnthonyShuffle_2

AnthonyShuffle_3.Name = "AnthonyShuffle"
AnthonyShuffle_3.Parent = ScrollingFrame
AnthonyShuffle_3.BackgroundColor3 = Color3.fromRGB(24, 24, 24)
AnthonyShuffle_3.Position = UDim2.new(0.0303030312, 0, 0.795385838, 0)
AnthonyShuffle_3.Size = UDim2.new(0, 245, 0, 21)
AnthonyShuffle_3.Font = Enum.Font.SourceSans
AnthonyShuffle_3.Text = "Fright Funk"
AnthonyShuffle_3.TextColor3 = Color3.fromRGB(255, 255, 255)
AnthonyShuffle_3.TextSize = 14.000

UICorner_7.Parent = AnthonyShuffle_3

AnthonyShuffle_4.Name = "AnthonyShuffle"
AnthonyShuffle_4.Parent = ScrollingFrame
AnthonyShuffle_4.BackgroundColor3 = Color3.fromRGB(24, 24, 24)
AnthonyShuffle_4.Position = UDim2.new(0.0303030312, 0, 0.795385838, 0)
AnthonyShuffle_4.Size = UDim2.new(0, 245, 0, 21)
AnthonyShuffle_4.Font = Enum.Font.SourceSans
AnthonyShuffle_4.Text = "Double Step"
AnthonyShuffle_4.TextColor3 = Color3.fromRGB(255, 255, 255)
AnthonyShuffle_4.TextSize = 14.000

UICorner_8.Parent = AnthonyShuffle_4

Chill.Name = "Chill"
Chill.Parent = ScrollingFrame
Chill.BackgroundColor3 = Color3.fromRGB(24, 24, 24)
Chill.Position = UDim2.new(0.0303030312, 0, 0.795385838, 0)
Chill.Size = UDim2.new(0, 245, 0, 21)
Chill.Font = Enum.Font.SourceSans
Chill.Text = "Chill"
Chill.TextColor3 = Color3.fromRGB(255, 255, 255)
Chill.TextSize = 14.000
Chill.MouseButton1Click:Connect(function()
	local KeyFrames = {
		{
			K = Keyframe,
			Poses = {
				Head = {
					CF = CFrame.new(0, -9.9837779998779e-06, 8.1062316894531e-06, 1, 0, 0, 0, 0.8003186583519, -0.59957486391068, 0, 0.59957486391068, 0.8003186583519),
					EasingDirection = Enum.PoseEasingDirection.In,
					EasingStyle = Enum.PoseEasingStyle.Linear
				},
				HumanoidRootPart = {
					CF = CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),
					EasingDirection = Enum.PoseEasingDirection.In,
					EasingStyle = Enum.PoseEasingStyle.Linear
				},
				Torso = {
					CF = CFrame.new(0, -0.00067174347350374, 10.250003814697, 1, 0, 0, 0, 6.5521395299584e-05, 1, 0, -1, 6.5521395299584e-05),
					EasingDirection = Enum.PoseEasingDirection.In,
					EasingStyle = Enum.PoseEasingStyle.Linear
				},
				["Left Arm"] = {
					CF = CFrame.new(3.2126903533936e-05, 0.14982736110687, -0.1610090136528, -0.2762556374073, -0.68574118614197, -0.67338067293167, 0.95788216590881, -0.13930985331535, -0.25110578536987, 0.078385055065155, -0.71438872814178, 0.69534462690353),
					EasingDirection = Enum.PoseEasingDirection.In,
					EasingStyle = Enum.PoseEasingStyle.Linear
				},
				["Left Leg"] = {
					CF = CFrame.new(-6.6757202148438e-06, 1.9609928131104e-05, 6.258487701416e-06, 0.91989207267761, 0.39217162132263, -1.3329554349184e-08, -0.39217153191566, 0.91989171504974, -0.00049209647113457, -0.00019297411199659, 0.00045268089161254, 0.99999988079071),
					EasingDirection = Enum.PoseEasingDirection.In,
					EasingStyle = Enum.PoseEasingStyle.Linear
				},
				["Right Arm"] = {
					CF = CFrame.new(-0.23933576047421, 0.048853062093258, -0.052183091640472, -0.31969684362411, 0.43647089600563, 0.84100359678268, -0.94017577171326, -0.25642031431198, -0.22431664168835, 0.11774277687073, -0.86240446567535, 0.49233621358871),
					EasingDirection = Enum.PoseEasingDirection.In,
					EasingStyle = Enum.PoseEasingStyle.Linear
				},
				["Right Leg"] = {
					CF = CFrame.new(-1.1488795280457e-05, 1.1146068572998e-05, -8.4042549133301e-06, 0.98106235265732, 0.19369207322598, -1.8597351214567e-08, -0.19369204342365, 0.98106199502945, -0.00049550156109035, -9.5956500445027e-05, 0.00048612162936479, 0.99999988079071),
					EasingDirection = Enum.PoseEasingDirection.In,
					EasingStyle = Enum.PoseEasingStyle.Linear
				}
			},
			Time = 0
		},
		{
			K = Keyframe,
			Poses = {
				Head = {
					CF = CFrame.new(0, 4.2319297790527e-06, -2.3424625396729e-05, 1, 0, 0, 0, 0.7509623169899, 0.66034513711929, 0, -0.66034513711929, 0.7509623169899),
					EasingDirection = Enum.PoseEasingDirection.In,
					EasingStyle = Enum.PoseEasingStyle.Linear
				},
				HumanoidRootPart = {
					CF = CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),
					EasingDirection = Enum.PoseEasingDirection.In,
					EasingStyle = Enum.PoseEasingStyle.Linear
				},
				Torso = {
					CF = CFrame.new(0, -0.00019353759125806, 2.8299958705902, 1, 0, 0, 0, 6.5521395299584e-05, 1, 0, -1, 6.5521395299584e-05),
					EasingDirection = Enum.PoseEasingDirection.In,
					EasingStyle = Enum.PoseEasingStyle.Linear
				},
				["Left Arm"] = {
					CF = CFrame.new(4.3779611587524e-05, 0.1498126834631, -0.16101014614105, -0.27625676989555, -0.8968819975853, -0.34537607431412, 0.95788198709488, -0.22763511538506, -0.17505407333374, 0.078383192420006, -0.37918940186501, 0.92199301719666),
					EasingDirection = Enum.PoseEasingDirection.In,
					EasingStyle = Enum.PoseEasingStyle.Linear
				},
				["Left Leg"] = {
					CF = CFrame.new(1.8179416656494e-05, 3.7252902984619e-06, 3.3974647521973e-06, 0.28783929347992, -0.95767855644226, -1.0855727872183e-08, 0.95767843723297, 0.28783911466599, -0.00049175694584846, 0.00047094843466766, 0.00014153655502014, 0.99999982118607),
					EasingDirection = Enum.PoseEasingDirection.In,
					EasingStyle = Enum.PoseEasingStyle.Linear
				},
				["Right Arm"] = {
					CF = CFrame.new(-0.2393566519022, 0.048832047730684, -0.052186973392963, -0.3196984231472, 0.84582680463791, 0.4270478785038, -0.94017481803894, -0.33918228745461, -0.032040514051914, 0.11774641275406, -0.41174286603928, 0.9036613702774),
					EasingDirection = Enum.PoseEasingDirection.In,
					EasingStyle = Enum.PoseEasingStyle.Linear
				},
				["Right Leg"] = {
					CF = CFrame.new(-4.1484832763672e-05, -2.0980834960938e-05, -5.1259994506836e-06, 0.80463188886642, 0.5937739610672, -1.2631065970936e-08, -0.59377384185791, 0.80463153123856, -0.00049134116852656, -0.00029173551592976, 0.00039535632822663, 0.99999988079071),
					EasingDirection = Enum.PoseEasingDirection.In,
					EasingStyle = Enum.PoseEasingStyle.Linear
				}
			},
			Time = 6
		},
		{
			K = Keyframe,
			Poses = {
				Head = {
					CF = CFrame.new(0, -9.9837779998779e-06, 8.1062316894531e-06, 1, 0, 0, 0, 0.8003186583519, -0.59957486391068, 0, 0.59957486391068, 0.8003186583519),
					EasingDirection = Enum.PoseEasingDirection.In,
					EasingStyle = Enum.PoseEasingStyle.Linear
				},
				HumanoidRootPart = {
					CF = CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),
					EasingDirection = Enum.PoseEasingDirection.In,
					EasingStyle = Enum.PoseEasingStyle.Linear
				},
				Torso = {
					CF = CFrame.new(0, -0.00067174347350374, 10.250003814697, 1, 0, 0, 0, 6.5521395299584e-05, 1, 0, -1, 6.5521395299584e-05),
					EasingDirection = Enum.PoseEasingDirection.In,
					EasingStyle = Enum.PoseEasingStyle.Linear
				},
				["Left Arm"] = {
					CF = CFrame.new(3.2126903533936e-05, 0.14982736110687, -0.1610090136528, -0.2762556374073, -0.68574118614197, -0.67338067293167, 0.95788216590881, -0.13930985331535, -0.25110578536987, 0.078385055065155, -0.71438872814178, 0.69534462690353),
					EasingDirection = Enum.PoseEasingDirection.In,
					EasingStyle = Enum.PoseEasingStyle.Linear
				},
				["Left Leg"] = {
					CF = CFrame.new(-6.6757202148438e-06, 1.9609928131104e-05, 6.258487701416e-06, 0.91989207267761, 0.39217162132263, -1.3329554349184e-08, -0.39217153191566, 0.91989171504974, -0.00049209647113457, -0.00019297411199659, 0.00045268089161254, 0.99999988079071),
					EasingDirection = Enum.PoseEasingDirection.In,
					EasingStyle = Enum.PoseEasingStyle.Linear
				},
				["Right Arm"] = {
					CF = CFrame.new(-0.23933576047421, 0.048853062093258, -0.052183091640472, -0.31969684362411, 0.43647089600563, 0.84100359678268, -0.94017577171326, -0.25642031431198, -0.22431664168835, 0.11774277687073, -0.86240446567535, 0.49233621358871),
					EasingDirection = Enum.PoseEasingDirection.In,
					EasingStyle = Enum.PoseEasingStyle.Linear
				},
				["Right Leg"] = {
					CF = CFrame.new(-1.1488795280457e-05, 1.1146068572998e-05, -8.4042549133301e-06, 0.98106235265732, 0.19369207322598, -1.8597351214567e-08, -0.19369204342365, 0.98106199502945, -0.00049550156109035, -9.5956500445027e-05, 0.00048612162936479, 0.99999988079071),
					EasingDirection = Enum.PoseEasingDirection.In,
					EasingStyle = Enum.PoseEasingStyle.Linear
				}
			},
			Time = 12
		}
	}

	loadstring(game:HttpGet('https://raw.githubusercontent.com/Alpha-404/NC-REANIM-V2/main/Reanimate.lua'))()

	local Character = workspace:WaitForChild('Rig')
	local Motors = {}
	local Normals = {}

	for i,v in pairs(Character:GetDescendants()) do
		if v:IsA("Motor6D") and v.Part0 and v.Part1  then
			Motors[tostring(v.Part1)] = v
			Normals[tostring(v.Part1)] = v.Transform
		end
	end 

	local function poseTweenInfo(t,s,g)
		local s = tostring(s)
		local g = tostring(g)
		local s = string.split(s,"Enum.PoseEasingStyle.")
		local g = string.split(g,"Enum.PoseEasingDirection.")
		local s = s[2]
		local g = g[2]
		local s = Enum.EasingStyle[s]
		local g = Enum.EasingDirection[g]
		return TweenInfo.new(t,s,g)
	end

	while wait() do
		for i,Keyframe in pairs(KeyFrames) do
			local LastKeyframe = KeyFrames[#KeyFrames-1] or Keyframe
			for PoseName,Pose in pairs(Keyframe.Poses) do
				local Inst = Motors[tostring(PoseName)]
				if Inst and Inst.Name ~= "HumanoidRootPart" then
					local waitTime = Keyframe.Time
					local PoseTween = game:GetService("TweenService"):Create(Motors[tostring(PoseName)],poseTweenInfo(waitTime,Pose.EasingStyle,Pose.EasingDirection),{Transform = Pose.CF})

					PoseTween:Play()
				end
			end
			wait(Keyframe.Time)
		end

		for i,v in pairs(Motors) do
			game:GetService("TweenService"):Create(v,TweenInfo.new(),{Transform = Normals[tostring(i)]}):Play()
		end
	end
end)

UICorner_9.Parent = Chill

Smug.Name = "Smug"
Smug.Parent = ScrollingFrame
Smug.BackgroundColor3 = Color3.fromRGB(24, 24, 24)
Smug.Position = UDim2.new(0.0303030312, 0, 0.795385838, 0)
Smug.Size = UDim2.new(0, 245, 0, 21)
Smug.Font = Enum.Font.SourceSans
Smug.Text = "Smug"
Smug.TextColor3 = Color3.fromRGB(255, 255, 255)
Smug.TextSize = 14.000
Smug.MouseButton1Click:Connect(function()
	local animid = "rbxassetid://4623829689"
	local speed = 0.02

	loadstring(game:HttpGet('https://raw.githubusercontent.com/Alpha-404/NC-REANIM-V2/main/Reanimate.lua'))()
	workspace:WaitForChild('Rig')

	Reanim_Rig=workspace.Rig
	cf=Reanim_Rig.HumanoidRootPart.CFrame
	t=Reanim_Rig.Torso
	rs=t["Right Shoulder"]
	ls=t["Left Shoulder"]
	rh=t["Right Hip"]
	lh=t["Left Hip"]
	n=t["Neck"]
	rj=Reanim_Rig.HumanoidRootPart["RootJoint"]
	rsc0=rs.C0
	lsc0=ls.C0
	rhc0=rh.C0
	lhc0=lh.C0
	rjc0=rj.C0
	nc0=n.C0
	gc0=CFrame.new()
	orsc0=rs.C0
	olsc0=ls.C0
	orhc0=rh.C0
	olhc0=lh.C0
	orjc0=rj.C0
	onc0=n.C0
	count2 = 100
	maxcount2=100
	game["Run Service"].Heartbeat:Connect(function()
		count2 = count2+1
		if count2<=maxcount2 then
			rs.Transform=rs.Transform:Lerp(rsc0,count2/maxcount2)
			ls.Transform=ls.Transform:Lerp(lsc0,count2/maxcount2)
			rh.Transform=rh.Transform:Lerp(rhc0,count2/maxcount2)
			lh.Transform=lh.Transform:Lerp(lhc0,count2/maxcount2)
			n.Transform=n.Transform:Lerp(nc0,count2/maxcount2)
			rj.Transform=rj.Transform:Lerp(rjc0,count2/maxcount2)
		end
	end)
	animid=game:GetObjects(animid)[1]
	function wait2(tim)
		if tim<0.1 then
			game.RunService.Heartbeat:Wait()
		else
			for i=1,tim*40 do
				game.RunService.Heartbeat:Wait()
			end
		end
	end
	anim={}
	function kftotbl(kf)
		local tbl3 = {}
		for i,v in pairs(kf:GetDescendants()) do
			if v:IsA("Pose") then
				tbl3[string.sub(v.Name,1,1)..string.sub(v.Name,#v.Name,#v.Name)] = v.CFrame
			end
		end
		return(tbl3)
	end
	for i,v in pairs(animid:GetChildren()) do
		if v:IsA("Keyframe") then
			anim[v.Time]=kftotbl(v)
		end
	end

	function getnext(tbl,number)
		local c=100
		local rtrnv=0
		for i,v in pairs(tbl) do
			if i>number and i-number<c then
				c=i-number
				rtrnv=i
			end
		end
		return(rtrnv)
	end
	count = 0
	char=workspace.Rig
	hhhh=workspace.Rig.Humanoid.Animator
	hhhh.Parent = nil
	for _,v in pairs(workspace.Rig.Humanoid:GetPlayingAnimationTracks()) do
		v:Stop()
	end
	while wait() do
		for i,oasjdadlasdkadkldjkl in pairs(anim) do
			asdf=getnext(anim,count)
			v=anim[asdf]
			if v["Lg"] then
				lhc0 = v["Lg"]
			end
			if v["Rg"] then
				rhc0 = v["Rg"]
			end
			if v["Lm"] then
				lsc0 = v["Lm"]
			end
			if v["Rm"] then
				rsc0 = v["Rm"]
			end
			if v["To"] then
				rjc0 = v["To"]
			end
			if v["Hd"] then
				nc0 = v["Hd"]
			end
			count2=0
			maxcount2=asdf-count
			count=asdf
			wait(speed)
			count2=maxcount2
			if v["Lg"] then
				char.Torso["Left Hip"].Transform = v["Lg"]
			end
			if v["Rg"] then
				char.Torso["Right Hip"].Transform = v["Rg"]
			end
			if v["Lm"] then
				char.Torso["Left Shoulder"].Transform = v["Lm"]
			end
			if v["Rm"] then
				char.Torso["Right Shoulder"].Transform = v["Rm"]
			end
			if v["To"] then
				char.HumanoidRootPart["RootJoint"].Transform = v["To"]
			end
			if v["Hd"] then
				char.Torso["Neck"].Transform = v["Hd"]
			end
		end
	end
end)

UICorner_10.Parent = Smug


Dirty.Name = "feorgjtoe"
Dirty.Parent = ScrollingFrame
Dirty.BackgroundColor3 = Color3.fromRGB(24, 24, 24)
Dirty.Position = UDim2.new(0.0303030312, 0, 0.795385838, 0)
Dirty.Size = UDim2.new(0, 245, 0, 21)
Dirty.Font = Enum.Font.SourceSans
Dirty.Text = "The Dirty"
Dirty.TextColor3 = Color3.fromRGB(255, 255, 255)
Dirty.TextSize = 14.000
UICorner_11.Parent = Dirty
Dirty.MouseButton1Click:Connect(function()
	local KeyFrames = {
		{
			K = Keyframe,
			Poses = {
				Head = {
					CF = CFrame.new(-0.0046220659278333, -1.0299910306931, -2.4899997711182, -0.99998992681503, -0.0044499645009637, 0.0005407456192188, 0.004482698161155, -0.99267572164536, 0.12072628736496, -4.4261105358601e-07, 0.1207275018096, 0.99268561601639),
					EasingDirection = Enum.PoseEasingDirection.In,
					EasingStyle = Enum.PoseEasingStyle.Linear
				},
				HumanoidRootPart = {
					CF = CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),
					EasingDirection = Enum.PoseEasingDirection.In,
					EasingStyle = Enum.PoseEasingStyle.Linear
				},
				Torso = {
					CF = CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),
					EasingDirection = Enum.PoseEasingDirection.In,
					EasingStyle = Enum.PoseEasingStyle.Linear
				},
				["Left Arm"] = {
					CF = CFrame.new(-0.25512915849686, -0.13839894533157, -0.24526935815811, 0.47681203484535, 0.66965103149414, -0.56940120458603, -0.87900519371033, 0.36325120925903, -0.30886596441269, 3.2186508178711e-06, 0.64777755737305, 0.76182955503464),
					EasingDirection = Enum.PoseEasingDirection.In,
					EasingStyle = Enum.PoseEasingStyle.Linear
				},
				["Right Arm"] = {
					CF = CFrame.new(0.29611521959305, 0.10839023441076, -0.37250113487244, 0.66733306646347, -0.72465425729752, 0.17188002169132, 0.70858198404312, 0.5467215180397, -0.44610178470612, 0.22929908335209, 0.41948956251144, 0.87832254171371),
					EasingDirection = Enum.PoseEasingDirection.In,
					EasingStyle = Enum.PoseEasingStyle.Linear
				}
			},
			Time = 0
		},
		{
			K = Keyframe,
			Poses = {
				Head = {
					CF = CFrame.new(-0.0032719359733164, -0.73218762874603, -2.526219367981, -0.99998968839645, -0.0045034238137305, 0.00054568389896303, 0.0045363637618721, -0.99267548322678, 0.12072627991438, -1.9945728126913e-06, 0.12072751671076, 0.99268579483032),
					EasingDirection = Enum.PoseEasingDirection.In,
					EasingStyle = Enum.PoseEasingStyle.Linear
				},
				HumanoidRootPart = {
					CF = CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),
					EasingDirection = Enum.PoseEasingDirection.In,
					EasingStyle = Enum.PoseEasingStyle.Linear
				},
				Torso = {
					CF = CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),
					EasingDirection = Enum.PoseEasingDirection.In,
					EasingStyle = Enum.PoseEasingStyle.Linear
				},
				["Left Arm"] = {
					CF = CFrame.new(-0.25512886047363, -0.13840019702911, -0.24527096748352, 0.66463154554367, 0.48378130793571, -0.56940364837646, -0.71834969520569, 0.62335884571075, -0.3088641166687, 0.20552022755146, 0.61431181430817, 0.7618283033371),
					EasingDirection = Enum.PoseEasingDirection.In,
					EasingStyle = Enum.PoseEasingStyle.Linear
				},
				["Right Arm"] = {
					CF = CFrame.new(0.29609403014183, 0.10838830471039, -0.37250143289566, 0.83729130029678, -0.51903706789017, 0.17188270390034, 0.53591531515121, 0.71678751707077, -0.44610512256622, 0.10834180563688, 0.46563452482224, 0.87832021713257),
					EasingDirection = Enum.PoseEasingDirection.In,
					EasingStyle = Enum.PoseEasingStyle.Linear
				}
			},
			Time = 0.10000000149012
		},
		{
			K = Keyframe,
			Poses = {
				Head = {
					CF = CFrame.new(-0.0046220659278333, -1.0299910306931, -2.4899997711182, -0.99998992681503, -0.0044499645009637, 0.0005407456192188, 0.004482698161155, -0.99267572164536, 0.12072628736496, -4.4261105358601e-07, 0.1207275018096, 0.99268561601639),
					EasingDirection = Enum.PoseEasingDirection.In,
					EasingStyle = Enum.PoseEasingStyle.Linear
				},
				HumanoidRootPart = {
					CF = CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),
					EasingDirection = Enum.PoseEasingDirection.In,
					EasingStyle = Enum.PoseEasingStyle.Linear
				},
				Torso = {
					CF = CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),
					EasingDirection = Enum.PoseEasingDirection.In,
					EasingStyle = Enum.PoseEasingStyle.Linear
				},
				["Left Arm"] = {
					CF = CFrame.new(-0.25512915849686, -0.13839894533157, -0.24526935815811, 0.47681203484535, 0.66965103149414, -0.56940120458603, -0.87900519371033, 0.36325120925903, -0.30886596441269, 3.2186508178711e-06, 0.64777755737305, 0.76182955503464),
					EasingDirection = Enum.PoseEasingDirection.In,
					EasingStyle = Enum.PoseEasingStyle.Linear
				},
				["Right Arm"] = {
					CF = CFrame.new(0.29611521959305, 0.10839023441076, -0.37250113487244, 0.66733306646347, -0.72465425729752, 0.17188002169132, 0.70858198404312, 0.5467215180397, -0.44610178470612, 0.22929908335209, 0.41948956251144, 0.87832254171371),
					EasingDirection = Enum.PoseEasingDirection.In,
					EasingStyle = Enum.PoseEasingStyle.Linear
				}
			},
			Time = 0.20000000298023
		}
	}

	loadstring(game:HttpGet('https://raw.githubusercontent.com/Alpha-404/NC-REANIM-V2/main/Reanimate.lua'))()

	local Character = workspace:WaitForChild('Rig')
	local Motors = {}
	local Normals = {}
	
	for i,v in pairs(Character:GetDescendants()) do
		if v:IsA("Motor6D") and v.Part0 and v.Part1  then
			Motors[tostring(v.Part1)] = v
			Normals[tostring(v.Part1)] = v.Transform
		end
	end 

	local function poseTweenInfo(t,s,g)
		local s = tostring(s)
		local g = tostring(g)
		local s = string.split(s,"Enum.PoseEasingStyle.")
		local g = string.split(g,"Enum.PoseEasingDirection.")
		local s = s[2]
		local g = g[2]
		local s = Enum.EasingStyle[s]
		local g = Enum.EasingDirection[g]
		return TweenInfo.new(t,s,g)
	end
	spawn(function()
		while wait() do
			for i,Keyframe in pairs(KeyFrames) do
				local LastKeyframe = KeyFrames[#KeyFrames-1] or Keyframe
				for PoseName,Pose in pairs(Keyframe.Poses) do
					local Inst = Motors[tostring(PoseName)]
					if Inst and Inst.Name ~= "HumanoidRootPart" then
						local waitTime = Keyframe.Time
						local PoseTween = game:GetService("TweenService"):Create(Motors[tostring(PoseName)],poseTweenInfo(waitTime,Pose.EasingStyle,Pose.EasingDirection),{Transform = Pose.CF})

						PoseTween:Play()
					end
				end
				wait(Keyframe.Time)
			end

			for i,v in pairs(Motors) do
				game:GetService("TweenService"):Create(v,TweenInfo.new(),{Transform = Normals[tostring(i)]}):Play()
			end
		end
	end)
end)


-- Scripts:

function SetSound(id)
	if workspace:FindFirstChild("Rig") then
		local sound = Instance.new("Sound", workspace.Rig)
		sound.Volume = 10
		sound.SoundId = id
		sound.Looped = true
		sound:Play()
	end
end

local function YPPITQ_fake_script() -- russian.LocalScript 
	local script = Instance.new('LocalScript', russian)

	script.Parent.MouseButton1Click:Connect(function()
		local animid = "rbxassetid://6170554295"

		loadstring(game:HttpGet('https://raw.githubusercontent.com/Alpha-404/NC-REANIM-V2/main/Reanimate.lua'))()
		workspace:WaitForChild('Rig')
		SetSound('rbxassetid://2341226836')

		Reanim_Rig=workspace.Rig
		cf=Reanim_Rig.HumanoidRootPart.CFrame
		t=Reanim_Rig.Torso
		rs=t["Right Shoulder"]
		ls=t["Left Shoulder"]
		rh=t["Right Hip"]
		lh=t["Left Hip"]
		n=t["Neck"]
		rj=Reanim_Rig.HumanoidRootPart["RootJoint"]
		rsc0=rs.C0
		lsc0=ls.C0
		rhc0=rh.C0
		lhc0=lh.C0
		rjc0=rj.C0
		nc0=n.C0
		gc0=CFrame.new()
		orsc0=rs.C0
		olsc0=ls.C0
		orhc0=rh.C0
		olhc0=lh.C0
		orjc0=rj.C0
		onc0=n.C0
		count2 = 100
		maxcount2=100
		game["Run Service"].Heartbeat:Connect(function()
			count2 = count2+1
			if count2<=maxcount2 then
				rs.Transform=rs.Transform:Lerp(rsc0,count2/maxcount2)
				ls.Transform=ls.Transform:Lerp(lsc0,count2/maxcount2)
				rh.Transform=rh.Transform:Lerp(rhc0,count2/maxcount2)
				lh.Transform=lh.Transform:Lerp(lhc0,count2/maxcount2)
				n.Transform=n.Transform:Lerp(nc0,count2/maxcount2)
				rj.Transform=rj.Transform:Lerp(rjc0,count2/maxcount2)
			end
		end)
		animid=game:GetObjects(animid)[1]
		function wait2(tim)
			if tim<0.1 then
				game.RunService.Heartbeat:Wait()
			else
				for i=1,tim*40 do
					game.RunService.Heartbeat:Wait()
				end
			end
		end
		anim={}
		function kftotbl(kf)
			local tbl3 = {}
			for i,v in pairs(kf:GetDescendants()) do
				if v:IsA("Pose") then
					tbl3[string.sub(v.Name,1,1)..string.sub(v.Name,#v.Name,#v.Name)] = v.CFrame
				end
			end
			return(tbl3)
		end
		for i,v in pairs(animid:GetChildren()) do
			if v:IsA("Keyframe") then
				anim[v.Time]=kftotbl(v)
			end
		end

		function getnext(tbl,number)
			local c=100
			local rtrnv=0
			for i,v in pairs(tbl) do
				if i>number and i-number<c then
					c=i-number
					rtrnv=i
				end
			end
			return(rtrnv)
		end
		count = 0
		char=workspace.Rig
		hhhh=workspace.Rig.Humanoid.Animator
		hhhh.Parent = nil
		for _,v in pairs(workspace.Rig.Humanoid:GetPlayingAnimationTracks()) do
			v:Stop()
		end
		while wait() do
			for i,oasjdadlasdkadkldjkl in pairs(anim) do
				asdf=getnext(anim,count)
				v=anim[asdf]
				if v["Lg"] then
					lhc0 = v["Lg"]
				end
				if v["Rg"] then
					rhc0 = v["Rg"]
				end
				if v["Lm"] then
					lsc0 = v["Lm"]
				end
				if v["Rm"] then
					rsc0 = v["Rm"]
				end
				if v["To"] then
					rjc0 = v["To"]
				end
				if v["Hd"] then
					nc0 = v["Hd"]
				end
				count2=0
				maxcount2=asdf-count
				wait(0)
				count=asdf
				count2=maxcount2
				if v["Lg"] then
					char.Torso["Left Hip"].Transform = v["Lg"]
				end
				if v["Rg"] then
					char.Torso["Right Hip"].Transform = v["Rg"]
				end
				if v["Lm"] then
					char.Torso["Left Shoulder"].Transform = v["Lm"]
				end
				if v["Rm"] then
					char.Torso["Right Shoulder"].Transform = v["Rm"]
				end
				if v["To"] then
					char.HumanoidRootPart["RootJoint"].Transform = v["To"]
				end
				if v["Hd"] then
					char.Torso["Neck"].Transform = v["Hd"]
				end
			end
		end
	end)
end
coroutine.wrap(YPPITQ_fake_script)()
local function MTJGL_fake_script() -- Crusin.LocalScript 
	local script = Instance.new('LocalScript', Crusin)

	script.Parent.MouseButton1Click:Connect(function()
		local animid = "rbxassetid://5079952034"
		local speed = 0.02

		loadstring(game:HttpGet('https://raw.githubusercontent.com/Alpha-404/NC-REANIM-V2/main/Reanimate.lua'))()
		workspace:WaitForChild('Rig')

		SetSound('rbxassetid://313905409')

		Reanim_Rig=workspace.Rig
		cf=Reanim_Rig.HumanoidRootPart.CFrame
		t=Reanim_Rig.Torso
		rs=t["Right Shoulder"]
		ls=t["Left Shoulder"]
		rh=t["Right Hip"]
		lh=t["Left Hip"]
		n=t["Neck"]
		rj=Reanim_Rig.HumanoidRootPart["RootJoint"]
		rsc0=rs.C0
		lsc0=ls.C0
		rhc0=rh.C0
		lhc0=lh.C0
		rjc0=rj.C0
		nc0=n.C0
		gc0=CFrame.new()
		orsc0=rs.C0
		olsc0=ls.C0
		orhc0=rh.C0
		olhc0=lh.C0
		orjc0=rj.C0
		onc0=n.C0
		count2 = 100
		maxcount2=100
		game["Run Service"].Heartbeat:Connect(function()
			count2 = count2+1
			if count2<=maxcount2 then
				rs.Transform=rs.Transform:Lerp(rsc0,count2/maxcount2)
				ls.Transform=ls.Transform:Lerp(lsc0,count2/maxcount2)
				rh.Transform=rh.Transform:Lerp(rhc0,count2/maxcount2)
				lh.Transform=lh.Transform:Lerp(lhc0,count2/maxcount2)
				n.Transform=n.Transform:Lerp(nc0,count2/maxcount2)
				rj.Transform=rj.Transform:Lerp(rjc0,count2/maxcount2)
			end
		end)
		animid=game:GetObjects(animid)[1]
		function wait2(tim)
			if tim<0.1 then
				game.RunService.Heartbeat:Wait()
			else
				for i=1,tim*40 do
					game.RunService.Heartbeat:Wait()
				end
			end
		end
		anim={}
		function kftotbl(kf)
			local tbl3 = {}
			for i,v in pairs(kf:GetDescendants()) do
				if v:IsA("Pose") then
					tbl3[string.sub(v.Name,1,1)..string.sub(v.Name,#v.Name,#v.Name)] = v.CFrame
				end
			end
			return(tbl3)
		end
		for i,v in pairs(animid:GetChildren()) do
			if v:IsA("Keyframe") then
				anim[v.Time]=kftotbl(v)
			end
		end

		function getnext(tbl,number)
			local c=100
			local rtrnv=0
			for i,v in pairs(tbl) do
				if i>number and i-number<c then
					c=i-number
					rtrnv=i
				end
			end
			return(rtrnv)
		end
		count = 0
		char=workspace.Rig
		hhhh=workspace.Rig.Humanoid.Animator
		hhhh.Parent = nil
		for _,v in pairs(workspace.Rig.Humanoid:GetPlayingAnimationTracks()) do
			v:Stop()
		end
		while wait() do
			for i,oasjdadlasdkadkldjkl in pairs(anim) do
				asdf=getnext(anim,count)
				v=anim[asdf]
				if v["Lg"] then
					lhc0 = v["Lg"]
				end
				if v["Rg"] then
					rhc0 = v["Rg"]
				end
				if v["Lm"] then
					lsc0 = v["Lm"]
				end
				if v["Rm"] then
					rsc0 = v["Rm"]
				end
				if v["To"] then
					rjc0 = v["To"]
				end
				if v["Hd"] then
					nc0 = v["Hd"]
				end
				count2=0
				maxcount2=asdf-count
				count=asdf
				wait(speed)
				count2=maxcount2
				char:WaitForChild("Torso")
				if v["Lg"] then
					char.Torso["Left Hip"].Transform = v["Lg"]
				end
				if v["Rg"] then
					char.Torso["Right Hip"].Transform = v["Rg"]
				end
				if v["Lm"] then
					char.Torso["Left Shoulder"].Transform = v["Lm"]
				end
				if v["Rm"] then
					char.Torso["Right Shoulder"].Transform = v["Rm"]
				end
				if v["To"] then
					char.HumanoidRootPart["RootJoint"].Transform = v["To"]
				end
				if v["Hd"] then
					char.Torso["Neck"].Transform = v["Hd"]
				end
			end
		end
	end)
end
coroutine.wrap(MTJGL_fake_script)()
local function JUJAPV_fake_script() -- Skibidi.LocalScript 
	local script = Instance.new('LocalScript', Skibidi)

	script.Parent.MouseButton1Click:Connect(function()
		local animid = "rbxassetid://4835795413"
		local speed = 0.02

		loadstring(game:HttpGet('https://raw.githubusercontent.com/Alpha-404/NC-REANIM-V2/main/Reanimate.lua'))()
		workspace:WaitForChild('Rig')

		SetSound('rbxassetid://5690496476')

		Reanim_Rig=workspace.Rig
		cf=Reanim_Rig.HumanoidRootPart.CFrame
		t=Reanim_Rig.Torso
		rs=t["Right Shoulder"]
		ls=t["Left Shoulder"]
		rh=t["Right Hip"]
		lh=t["Left Hip"]
		n=t["Neck"]
		rj=Reanim_Rig.HumanoidRootPart["RootJoint"]
		rsc0=rs.C0
		lsc0=ls.C0
		rhc0=rh.C0
		lhc0=lh.C0
		rjc0=rj.C0
		nc0=n.C0
		gc0=CFrame.new()
		orsc0=rs.C0
		olsc0=ls.C0
		orhc0=rh.C0
		olhc0=lh.C0
		orjc0=rj.C0
		onc0=n.C0
		count2 = 100
		maxcount2=100
		game["Run Service"].Heartbeat:Connect(function()
			count2 = count2+1
			if count2<=maxcount2 then
				rs.Transform=rs.Transform:Lerp(rsc0,count2/maxcount2)
				ls.Transform=ls.Transform:Lerp(lsc0,count2/maxcount2)
				rh.Transform=rh.Transform:Lerp(rhc0,count2/maxcount2)
				lh.Transform=lh.Transform:Lerp(lhc0,count2/maxcount2)
				n.Transform=n.Transform:Lerp(nc0,count2/maxcount2)
				rj.Transform=rj.Transform:Lerp(rjc0,count2/maxcount2)
			end
		end)
		animid=game:GetObjects(animid)[1]
		function wait2(tim)
			if tim<0.1 then
				game.RunService.Heartbeat:Wait()
			else
				for i=1,tim*40 do
					game.RunService.Heartbeat:Wait()
				end
			end
		end
		anim={}
		function kftotbl(kf)
			local tbl3 = {}
			for i,v in pairs(kf:GetDescendants()) do
				if v:IsA("Pose") then
					tbl3[string.sub(v.Name,1,1)..string.sub(v.Name,#v.Name,#v.Name)] = v.CFrame
				end
			end
			return(tbl3)
		end
		for i,v in pairs(animid:GetChildren()) do
			if v:IsA("Keyframe") then
				anim[v.Time]=kftotbl(v)
			end
		end

		function getnext(tbl,number)
			local c=100
			local rtrnv=0
			for i,v in pairs(tbl) do
				if i>number and i-number<c then
					c=i-number
					rtrnv=i
				end
			end
			return(rtrnv)
		end
		count = 0
		char=workspace.Rig
		hhhh=workspace.Rig.Humanoid.Animator
		hhhh.Parent = nil
		for _,v in pairs(workspace.Rig.Humanoid:GetPlayingAnimationTracks()) do
			v:Stop()
		end
		while wait() do
			for i,oasjdadlasdkadkldjkl in pairs(anim) do
				asdf=getnext(anim,count)
				v=anim[asdf]
				if v["Lg"] then
					lhc0 = v["Lg"]
				end
				if v["Rg"] then
					rhc0 = v["Rg"]
				end
				if v["Lm"] then
					lsc0 = v["Lm"]
				end
				if v["Rm"] then
					rsc0 = v["Rm"]
				end
				if v["To"] then
					rjc0 = v["To"]
				end
				if v["Hd"] then
					nc0 = v["Hd"]
				end
				count2=0
				maxcount2=asdf-count
				count=asdf
				wait(speed)
				count2=maxcount2
				if v["Lg"] then
					char.Torso["Left Hip"].Transform = v["Lg"]
				end
				if v["Rg"] then
					char.Torso["Right Hip"].Transform = v["Rg"]
				end
				if v["Lm"] then
					char.Torso["Left Shoulder"].Transform = v["Lm"]
				end
				if v["Rm"] then
					char.Torso["Right Shoulder"].Transform = v["Rm"]
				end
				if v["To"] then
					char.HumanoidRootPart["RootJoint"].Transform = v["To"]
				end
				if v["Hd"] then
					char.Torso["Neck"].Transform = v["Hd"]
				end
			end
		end
	end)
end
coroutine.wrap(JUJAPV_fake_script)()
local function ODTA_fake_script() -- AnthonyShuffle.LocalScript 
	local script = Instance.new('LocalScript', AnthonyShuffle)

	script.Parent.MouseButton1Click:Connect(function()
		local animid = "rbxassetid://4837748730"
		local speed = 0.02

		loadstring(game:HttpGet('https://raw.githubusercontent.com/Alpha-404/NC-REANIM-V2/main/Reanimate.lua'))()
		workspace:WaitForChild('Rig')

		SetSound('rbxassetid://4747544134')

		Reanim_Rig=workspace.Rig
		cf=Reanim_Rig.HumanoidRootPart.CFrame
		t=Reanim_Rig.Torso
		rs=t["Right Shoulder"]
		ls=t["Left Shoulder"]
		rh=t["Right Hip"]
		lh=t["Left Hip"]
		n=t["Neck"]
		rj=Reanim_Rig.HumanoidRootPart["RootJoint"]
		rsc0=rs.C0
		lsc0=ls.C0
		rhc0=rh.C0
		lhc0=lh.C0
		rjc0=rj.C0
		nc0=n.C0
		gc0=CFrame.new()
		orsc0=rs.C0
		olsc0=ls.C0
		orhc0=rh.C0
		olhc0=lh.C0
		orjc0=rj.C0
		onc0=n.C0
		count2 = 100
		maxcount2=100
		game["Run Service"].Heartbeat:Connect(function()
			count2 = count2+1
			if count2<=maxcount2 then
				rs.Transform=rs.Transform:Lerp(rsc0,count2/maxcount2)
				ls.Transform=ls.Transform:Lerp(lsc0,count2/maxcount2)
				rh.Transform=rh.Transform:Lerp(rhc0,count2/maxcount2)
				lh.Transform=lh.Transform:Lerp(lhc0,count2/maxcount2)
				n.Transform=n.Transform:Lerp(nc0,count2/maxcount2)
				rj.Transform=rj.Transform:Lerp(rjc0,count2/maxcount2)
			end
		end)
		animid=game:GetObjects(animid)[1]
		function wait2(tim)
			if tim<0.1 then
				game.RunService.Heartbeat:Wait()
			else
				for i=1,tim*40 do
					game.RunService.Heartbeat:Wait()
				end
			end
		end
		anim={}
		function kftotbl(kf)
			local tbl3 = {}
			for i,v in pairs(kf:GetDescendants()) do
				if v:IsA("Pose") then
					tbl3[string.sub(v.Name,1,1)..string.sub(v.Name,#v.Name,#v.Name)] = v.CFrame
				end
			end
			return(tbl3)
		end
		for i,v in pairs(animid:GetChildren()) do
			if v:IsA("Keyframe") then
				anim[v.Time]=kftotbl(v)
			end
		end

		function getnext(tbl,number)
			local c=100
			local rtrnv=0
			for i,v in pairs(tbl) do
				if i>number and i-number<c then
					c=i-number
					rtrnv=i
				end
			end
			return(rtrnv)
		end
		count = 0
		char=workspace.Rig
		hhhh=workspace.Rig.Humanoid.Animator
		hhhh.Parent = nil
		for _,v in pairs(workspace.Rig.Humanoid:GetPlayingAnimationTracks()) do
			v:Stop()
		end
		while wait() do
			for i,oasjdadlasdkadkldjkl in pairs(anim) do
				asdf=getnext(anim,count)
				v=anim[asdf]
				if v["Lg"] then
					lhc0 = v["Lg"]
				end
				if v["Rg"] then
					rhc0 = v["Rg"]
				end
				if v["Lm"] then
					lsc0 = v["Lm"]
				end
				if v["Rm"] then
					rsc0 = v["Rm"]
				end
				if v["To"] then
					rjc0 = v["To"]
				end
				if v["Hd"] then
					nc0 = v["Hd"]
				end
				count2=0
				maxcount2=asdf-count
				count=asdf
				wait(speed)
				count2=maxcount2
				if v["Lg"] then
					char.Torso["Left Hip"].Transform = v["Lg"]
				end
				if v["Rg"] then
					char.Torso["Right Hip"].Transform = v["Rg"]
				end
				if v["Lm"] then
					char.Torso["Left Shoulder"].Transform = v["Lm"]
				end
				if v["Rm"] then
					char.Torso["Right Shoulder"].Transform = v["Rm"]
				end
				if v["To"] then
					char.HumanoidRootPart["RootJoint"].Transform = v["To"]
				end
				if v["Hd"] then
					char.Torso["Neck"].Transform = v["Hd"]
				end
			end
		end
	end)
end
coroutine.wrap(ODTA_fake_script)()
local function PQERAAY_fake_script() -- AnthonyShuffle_2.LocalScript 
	local script = Instance.new('LocalScript', AnthonyShuffle_2)

	script.Parent.MouseButton1Click:Connect(function()
		local animid = "rbxassetid://5025546871"

		loadstring(game:HttpGet('https://raw.githubusercontent.com/Alpha-404/NC-REANIM-V2/main/Reanimate.lua'))()
		workspace:WaitForChild('Rig')

		SetSound('rbxassetid://1986432404')

		Reanim_Rig=workspace.Rig
		cf=Reanim_Rig.HumanoidRootPart.CFrame
		t=Reanim_Rig.Torso
		rs=t["Right Shoulder"]
		ls=t["Left Shoulder"]
		rh=t["Right Hip"]
		lh=t["Left Hip"]
		n=t["Neck"]
		rj=Reanim_Rig.HumanoidRootPart["RootJoint"]
		rsc0=rs.C0
		lsc0=ls.C0
		rhc0=rh.C0
		lhc0=lh.C0
		rjc0=rj.C0
		nc0=n.C0
		gc0=CFrame.new()
		orsc0=rs.C0
		olsc0=ls.C0
		orhc0=rh.C0
		olhc0=lh.C0
		orjc0=rj.C0
		onc0=n.C0
		count2 = 100
		maxcount2=100
		game["Run Service"].Heartbeat:Connect(function()
			count2 = count2+1
			if count2<=maxcount2 then
				rs.Transform=rs.Transform:Lerp(rsc0,count2/maxcount2)
				ls.Transform=ls.Transform:Lerp(lsc0,count2/maxcount2)
				rh.Transform=rh.Transform:Lerp(rhc0,count2/maxcount2)
				lh.Transform=lh.Transform:Lerp(lhc0,count2/maxcount2)
				n.Transform=n.Transform:Lerp(nc0,count2/maxcount2)
				rj.Transform=rj.Transform:Lerp(rjc0,count2/maxcount2)
			end
		end)
		animid=game:GetObjects(animid)[1]
		function wait2(tim)
			if tim<0.1 then
				game.RunService.Heartbeat:Wait()
			else
				for i=1,tim*40 do
					game.RunService.Heartbeat:Wait()
				end
			end
		end
		anim={}
		function kftotbl(kf)
			local tbl3 = {}
			for i,v in pairs(kf:GetDescendants()) do
				if v:IsA("Pose") then
					tbl3[string.sub(v.Name,1,1)..string.sub(v.Name,#v.Name,#v.Name)] = v.CFrame
				end
			end
			return(tbl3)
		end
		for i,v in pairs(animid:GetChildren()) do
			if v:IsA("Keyframe") then
				anim[v.Time]=kftotbl(v)
			end
		end

		function getnext(tbl,number)
			local c=100
			local rtrnv=0
			for i,v in pairs(tbl) do
				if i>number and i-number<c then
					c=i-number
					rtrnv=i
				end
			end
			return(rtrnv)
		end
		count = 0
		char=workspace.Rig
		hhhh=workspace.Rig.Humanoid.Animator
		hhhh.Parent = nil
		for _,v in pairs(workspace.Rig.Humanoid:GetPlayingAnimationTracks()) do
			v:Stop()
		end
		while wait() do
			for i,oasjdadlasdkadkldjkl in pairs(anim) do
				asdf=getnext(anim,count)
				v=anim[asdf]
				if v["Lg"] then
					lhc0 = v["Lg"]
				end
				if v["Rg"] then
					rhc0 = v["Rg"]
				end
				if v["Lm"] then
					lsc0 = v["Lm"]
				end
				if v["Rm"] then
					rsc0 = v["Rm"]
				end
				if v["To"] then
					rjc0 = v["To"]
				end
				if v["Hd"] then
					nc0 = v["Hd"]
				end
				count2=0
				maxcount2=asdf-count
				count=asdf
				wait(0.03)
				count2=maxcount2
				if v["Lg"] then
					char.Torso["Left Hip"].Transform = v["Lg"]
				end
				if v["Rg"] then
					char.Torso["Right Hip"].Transform = v["Rg"]
				end
				if v["Lm"] then
					char.Torso["Left Shoulder"].Transform = v["Lm"]
				end
				if v["Rm"] then
					char.Torso["Right Shoulder"].Transform = v["Rm"]
				end
				if v["To"] then
					char.HumanoidRootPart["RootJoint"].Transform = v["To"]
				end
				if v["Hd"] then
					char.Torso["Neck"].Transform = v["Hd"]
				end
			end
		end
	end)
end
coroutine.wrap(PQERAAY_fake_script)()
local function WTZME_fake_script() -- AnthonyShuffle_3.LocalScript 
	local script = Instance.new('LocalScript', AnthonyShuffle_3)

	script.Parent.MouseButton1Click:Connect(function()
		local animid = "rbxassetid://5596328928"
		local speed = 0.02

		loadstring(game:HttpGet('https://raw.githubusercontent.com/Alpha-404/NC-REANIM-V2/main/Reanimate.lua'))()
		workspace:WaitForChild('Rig')

		SetSound('rbxassetid://6376708678')

		Reanim_Rig=workspace.Rig
		cf=Reanim_Rig.HumanoidRootPart.CFrame
		t=Reanim_Rig.Torso
		rs=t["Right Shoulder"]
		ls=t["Left Shoulder"]
		rh=t["Right Hip"]
		lh=t["Left Hip"]
		n=t["Neck"]
		rj=Reanim_Rig.HumanoidRootPart["RootJoint"]
		rsc0=rs.C0
		lsc0=ls.C0
		rhc0=rh.C0
		lhc0=lh.C0
		rjc0=rj.C0
		nc0=n.C0
		gc0=CFrame.new()
		orsc0=rs.C0
		olsc0=ls.C0
		orhc0=rh.C0
		olhc0=lh.C0
		orjc0=rj.C0
		onc0=n.C0
		count2 = 100
		maxcount2=100
		game["Run Service"].Heartbeat:Connect(function()
			count2 = count2+1
			if count2<=maxcount2 then
				rs.Transform=rs.Transform:Lerp(rsc0,count2/maxcount2)
				ls.Transform=ls.Transform:Lerp(lsc0,count2/maxcount2)
				rh.Transform=rh.Transform:Lerp(rhc0,count2/maxcount2)
				lh.Transform=lh.Transform:Lerp(lhc0,count2/maxcount2)
				n.Transform=n.Transform:Lerp(nc0,count2/maxcount2)
				rj.Transform=rj.Transform:Lerp(rjc0,count2/maxcount2)
			end
		end)
		animid=game:GetObjects(animid)[1]
		function wait2(tim)
			if tim<0.1 then
				game.RunService.Heartbeat:Wait()
			else
				for i=1,tim*40 do
					game.RunService.Heartbeat:Wait()
				end
			end
		end
		anim={}
		function kftotbl(kf)
			local tbl3 = {}
			for i,v in pairs(kf:GetDescendants()) do
				if v:IsA("Pose") then
					tbl3[string.sub(v.Name,1,1)..string.sub(v.Name,#v.Name,#v.Name)] = v.CFrame
				end
			end
			return(tbl3)
		end
		for i,v in pairs(animid:GetChildren()) do
			if v:IsA("Keyframe") then
				anim[v.Time]=kftotbl(v)
			end
		end

		function getnext(tbl,number)
			local c=100
			local rtrnv=0
			for i,v in pairs(tbl) do
				if i>number and i-number<c then
					c=i-number
					rtrnv=i
				end
			end
			return(rtrnv)
		end
		count = 0
		char=workspace.Rig
		hhhh=workspace.Rig.Humanoid.Animator
		hhhh.Parent = nil
		for _,v in pairs(workspace.Rig.Humanoid:GetPlayingAnimationTracks()) do
			v:Stop()
		end
		while wait() do
			for i,oasjdadlasdkadkldjkl in pairs(anim) do
				asdf=getnext(anim,count)
				v=anim[asdf]
				if v["Lg"] then
					lhc0 = v["Lg"]
				end
				if v["Rg"] then
					rhc0 = v["Rg"]
				end
				if v["Lm"] then
					lsc0 = v["Lm"]
				end
				if v["Rm"] then
					rsc0 = v["Rm"]
				end
				if v["To"] then
					rjc0 = v["To"]
				end
				if v["Hd"] then
					nc0 = v["Hd"]
				end
				count2=0
				maxcount2=asdf-count
				count=asdf
				wait(speed)
				count2=maxcount2
				if v["Lg"] then
					char.Torso["Left Hip"].Transform = v["Lg"]
				end
				if v["Rg"] then
					char.Torso["Right Hip"].Transform = v["Rg"]
				end
				if v["Lm"] then
					char.Torso["Left Shoulder"].Transform = v["Lm"]
				end
				if v["Rm"] then
					char.Torso["Right Shoulder"].Transform = v["Rm"]
				end
				if v["To"] then
					char.HumanoidRootPart["RootJoint"].Transform = v["To"]
				end
				if v["Hd"] then
					char.Torso["Neck"].Transform = v["Hd"]
				end
			end
		end
	end)
end
coroutine.wrap(WTZME_fake_script)()
local function MAGLVMQ_fake_script() -- AnthonyShuffle_4.LocalScript 
	local script = Instance.new('LocalScript', AnthonyShuffle_4)

	script.Parent.MouseButton1Click:Connect(function()
		local animid = "rbxassetid://4715102040"
		local speed = 0.02

		loadstring(game:HttpGet('https://raw.githubusercontent.com/Alpha-404/NC-REANIM-V2/main/Reanimate.lua'))()
		workspace:WaitForChild('Rig')

		SetSound('rbxassetid://1835564864')

		Reanim_Rig=workspace.Rig
		cf=Reanim_Rig.HumanoidRootPart.CFrame
		t=Reanim_Rig.Torso
		rs=t["Right Shoulder"]
		ls=t["Left Shoulder"]
		rh=t["Right Hip"]
		lh=t["Left Hip"]
		n=t["Neck"]
		rj=Reanim_Rig.HumanoidRootPart["RootJoint"]
		rsc0=rs.C0
		lsc0=ls.C0
		rhc0=rh.C0
		lhc0=lh.C0
		rjc0=rj.C0
		nc0=n.C0
		gc0=CFrame.new()
		orsc0=rs.C0
		olsc0=ls.C0
		orhc0=rh.C0
		olhc0=lh.C0
		orjc0=rj.C0
		onc0=n.C0
		count2 = 100
		maxcount2=100
		game["Run Service"].Heartbeat:Connect(function()
			count2 = count2+1
			if count2<=maxcount2 then
				rs.Transform=rs.Transform:Lerp(rsc0,count2/maxcount2)
				ls.Transform=ls.Transform:Lerp(lsc0,count2/maxcount2)
				rh.Transform=rh.Transform:Lerp(rhc0,count2/maxcount2)
				lh.Transform=lh.Transform:Lerp(lhc0,count2/maxcount2)
				n.Transform=n.Transform:Lerp(nc0,count2/maxcount2)
				rj.Transform=rj.Transform:Lerp(rjc0,count2/maxcount2)
			end
		end)
		animid=game:GetObjects(animid)[1]
		function wait2(tim)
			if tim<0.1 then
				game.RunService.Heartbeat:Wait()
			else
				for i=1,tim*40 do
					game.RunService.Heartbeat:Wait()
				end
			end
		end
		anim={}
		function kftotbl(kf)
			local tbl3 = {}
			for i,v in pairs(kf:GetDescendants()) do
				if v:IsA("Pose") then
					tbl3[string.sub(v.Name,1,1)..string.sub(v.Name,#v.Name,#v.Name)] = v.CFrame
				end
			end
			return(tbl3)
		end
		for i,v in pairs(animid:GetChildren()) do
			if v:IsA("Keyframe") then
				anim[v.Time]=kftotbl(v)
			end
		end

		function getnext(tbl,number)
			local c=100
			local rtrnv=0
			for i,v in pairs(tbl) do
				if i>number and i-number<c then
					c=i-number
					rtrnv=i
				end
			end
			return(rtrnv)
		end
		count = 0
		char=workspace.Rig
		hhhh=workspace.Rig.Humanoid.Animator
		hhhh.Parent = nil
		for _,v in pairs(workspace.Rig.Humanoid:GetPlayingAnimationTracks()) do
			v:Stop()
		end
		while wait() do
			for i,oasjdadlasdkadkldjkl in pairs(anim) do
				asdf=getnext(anim,count)
				v=anim[asdf]
				if v["Lg"] then
					lhc0 = v["Lg"]
				end
				if v["Rg"] then
					rhc0 = v["Rg"]
				end
				if v["Lm"] then
					lsc0 = v["Lm"]
				end
				if v["Rm"] then
					rsc0 = v["Rm"]
				end
				if v["To"] then
					rjc0 = v["To"]
				end
				if v["Hd"] then
					nc0 = v["Hd"]
				end
				count2=0
				maxcount2=asdf-count
				count=asdf
				wait(speed)
				count2=maxcount2
				if v["Lg"] then
					char.Torso["Left Hip"].Transform = v["Lg"]
				end
				if v["Rg"] then
					char.Torso["Right Hip"].Transform = v["Rg"]
				end
				if v["Lm"] then
					char.Torso["Left Shoulder"].Transform = v["Lm"]
				end
				if v["Rm"] then
					char.Torso["Right Shoulder"].Transform = v["Rm"]
				end
				if v["To"] then
					char.HumanoidRootPart["RootJoint"].Transform = v["To"]
				end
				if v["Hd"] then
					char.Torso["Neck"].Transform = v["Hd"]
				end
			end
		end
	end)
end
coroutine.wrap(MAGLVMQ_fake_script)()
local function QTVEHK_fake_script() -- Shadow.LocalScript 
	local script = Instance.new('LocalScript', Shadow)

	local L_1_ = game:GetService("UserInputService")
	function drag(L_2_arg1)
		dragToggle = nil
		local dragSpeed = 0.23
		dragInput = nil
		dragStart = nil
		local dragPos = nil
		function updateInput(L_3_arg1)
			local Delta = L_3_arg1.Position - dragStart
			local Position = UDim2.new(startPos.X.Scale, startPos.X.Offset + Delta.X, startPos.Y.Scale, startPos.Y.Offset + Delta.Y)
			game:GetService("TweenService"):Create(L_2_arg1, TweenInfo.new(0.25), {
				Position = Position
			}):Play()
		end
		L_2_arg1.InputBegan:Connect(function(L_4_arg1)
			if (L_4_arg1.UserInputType == Enum.UserInputType.MouseButton1 or L_4_arg1.UserInputType == Enum.UserInputType.Touch) and L_1_:GetFocusedTextBox() == nil then
				dragToggle = true
				dragStart = L_4_arg1.Position
				startPos = L_2_arg1.Position
				L_4_arg1.Changed:Connect(function()
					if L_4_arg1.UserInputState == Enum.UserInputState.End then
						dragToggle = false
					end
				end)
			end
		end)
		L_2_arg1.InputChanged:Connect(function(L_5_arg1)
			if L_5_arg1.UserInputType == Enum.UserInputType.MouseMovement or L_5_arg1.UserInputType == Enum.UserInputType.Touch then
				dragInput = L_5_arg1
			end
		end)
		game:GetService("UserInputService").InputChanged:Connect(function(L_6_arg1)
			if L_6_arg1 == dragInput and dragToggle then
				updateInput(L_6_arg1)
			end
		end)
	end
	drag(script.Parent)
end
coroutine.wrap(QTVEHK_fake_script)()
