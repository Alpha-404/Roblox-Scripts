local p = game:GetService("Players").LocalPlayer
local char = p.Character

loadstring(game:HttpGet('https://raw.githubusercontent.com/Alpha-404/NC-REANIM-V2/main/Reanimate.lua'))()
workspace:WaitForChild('Rig')

local speed = 2

local c = workspace.Rig
wait()
if p.Character:FindFirstChild("Torso") then 
    p.Character.Torso:Destroy()
else
   p.Character.UpperTorso:Destroy()
   p.Character.LowerTorso:Destroy()
end
c.Humanoid.PlatformStand = true
local Root = c["Head"]
local BV = Instance.new("BodyVelocity", Root)
local BG = Instance.new("BodyGyro", Root)
local MD = false
flying = true
BG.MaxTorque = Vector3.new(math.huge*math.huge,math.huge*math.huge,math.huge*math.huge)
BV.MaxForce = Vector3.new(math.huge*math.huge,math.huge*math.huge,math.huge*math.huge)
BV.Velocity = Vector3.new(0,0,0)
char.Humanoid.WalkSpeed = 0
char.Humanoid.JumpPower = 0
c.Humanoid.WalkSpeed = 0
c.Humanoid.JumpPower = 0
workspace.CurrentCamera.CameraSubject = Root

local flyreq = game:GetService('UserInputService').InputBegan:Connect(function(key, gay)
	if gay then return end
	if key.KeyCode == Enum.KeyCode.W then
		while game:GetService("UserInputService"):IsKeyDown(Enum.KeyCode.W) do
			BV.Velocity += workspace.CurrentCamera.CFrame.LookVector * speed
			wait()
		end
		BV.Velocity = Vector3.new(0,0,0)
	elseif key.KeyCode == Enum.KeyCode.S then
		while game:GetService("UserInputService"):IsKeyDown(Enum.KeyCode.S) do
			BV.Velocity -= workspace.CurrentCamera.CFrame.LookVector * 4
			wait()
		end
		BV.Velocity = Vector3.new(0,0,0)
	elseif key.KeyCode == Enum.KeyCode.F then
		game:GetService("TweenService"):Create(RA, TweenInfo.new(0.3), {['CFrame'] = CFrame.new(-2, -1, 1.5, 0.766044438, -0.642787576, 0, 0.642787576, 0.766044438, -0, 0, 0, 0.99999994)}):Play()
		wait(0.3)
		game:GetService("TweenService"):Create(RA, TweenInfo.new(0.3), {['CFrame'] = CFrame.new(-0, -0.100000001, 1.5, 0.766044438, 0.642787576, -0, -0.642787576, 0.766044438, 0, 0, 0, 0.99999994)}):Play()
		wait(0.3)
		game:GetService("TweenService"):Create(RA, TweenInfo.new(0.3), {['CFrame'] = CFrame.new(-2, -1, 1.5, 0.766044438, -0.642787576, 0, 0.642787576, 0.766044438, -0, 0, 0, 0.99999994)}):Play()
		wait(0.3)
		game:GetService("TweenService"):Create(RA, TweenInfo.new(0.3), {['CFrame'] = CFrame.new(-1, 1.5, -1.5, 1, 0, 0, 0, -4.37113883e-08, 1, 0, -1, -4.37113883e-08)}):Play()
	end
end)

local MUP = p:GetMouse().Button1Up:Connect(function()
	MD = false
end)

local MDOWN = p:GetMouse().Button1Down:Connect(function()
	if MD then return end
	MD = true
	if p:GetMouse().Target == nil then return end
	if p:GetMouse().Target.Anchored == true then return end
	if not game:GetService("UserInputService"):IsKeyDown(Enum.KeyCode.Q) then return end
	local part = p:GetMouse().Target
	part.CanCollide = false
	local BP = Instance.new("BodyPosition", part)
	BP.MaxForce = Vector3.new(math.huge*math.huge,math.huge*math.huge,math.huge*math.huge)
	repeat
		BP.Position = p:GetMouse().Hit.Position
		wait()
	until MD == false
	part.CanCollide = true
	BP:Destroy()
end)

c:FindFirstChildOfClass("Humanoid").Died:Connect(function()
	flying = false
	flyreq:Disconnect()
	BV:Destroy()
	BG:Destroy()
	MUP:Disconnect()
	MDOWN:Disconnect()
end)

spawn(function()
	repeat
		wait()
		BG.CFrame = workspace.CurrentCamera.CFrame
	until flying == false 
	flyreq:Disconnect()
	BV:Destroy()
	BG:Destroy()
end)

for i,v in pairs(char:GetDescendants()) do
	if v:IsA("Clothing") or v:IsA("ShirtGraphic") then
		v:Destroy()
	end
end

for i,v in pairs(c.Torso:GetChildren()) do
	if v:IsA("Motor6D") and v.Name ~= "Neck" then
		v:Destroy()
	end
end

if c:FindFirstChild("ForceField") then
	c.ForceField:Destroy() 
end

local BSC_LL = Instance.new("BallSocketConstraint", c["Left Leg"])
local A = Instance.new("Attachment", c["Left Leg"])
local B = Instance.new("Attachment", c["Right Leg"])
BSC_LL.Attachment0 = A
BSC_LL.Attachment1 = B
A.Position = Vector3.new(0,2,0)
A.Name = "Connector"

local BSC_LL = Instance.new("BallSocketConstraint", c["Left Arm"])
local A = Instance.new("Attachment", c["Left Arm"])
local B = Instance.new("Attachment", c["Right Arm"])
BSC_LL.Attachment0 = A
BSC_LL.Attachment1 = B
A.Position = Vector3.new(0,2,0)
A.Name = "Connector"

local BSC_LL = Instance.new("BallSocketConstraint", c["Right Leg"])
local A = Instance.new("Attachment", c["Right Leg"])
local B = Instance.new("Attachment", c["Left Leg"])
BSC_LL.Attachment0 = A
BSC_LL.Attachment1 = B
A.Position = Vector3.new(0, 2.5, 0)
A.Name = "Connector"

local BSC_LL = Instance.new("BallSocketConstraint", c["Right Arm"])
local A = Instance.new("Attachment", c["Right Arm"])
local B = Instance.new("Attachment", c["Left Leg"])
BSC_LL.Attachment0 = A
BSC_LL.Attachment1 = B
A.Position = Vector3.new(0, 2, 0)
A.Name = "Connector"

Joint(c["Left Leg"], c["Head"], Vector3.new(0,-3.7,0), Vector3.new(0,0,0))