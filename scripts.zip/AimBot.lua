local teamcheck = true

game:GetService("UserInputService").InputBegan:Connect(function(key, gay)
	if gay then return end
	if key.KeyCode == Enum.KeyCode.E then
		local tar = game:GetService("Players").LocalPlayer:GetMouse().Target
		if tar.Parent:FindFirstChildOfClass("Humanoid") and tar ~= nil and tar:IsDescendantOf(game:GetService("Players").LocalPlayer.Character) == false and tar.Parent:FindFirstChild("Head") then
		    local hum = tar.Parent:FindFirstChildOfClass("Humanoid")
	        if teamcheck and game:GetService("Players"):GetPlayerFromCharacter(tar.Parent).Team ~= game:GetService("Players").LocalPlayer.Team then
			    while game:GetService("UserInputService"):IsKeyDown(Enum.KeyCode.E) do
			        if tar == nil then break end
			        if hum.Health == 0 then break end
			    	workspace.CurrentCamera.CFrame = CFrame.new(workspace.CurrentCamera.CFrame.Position, tar.Parent.Head.CFrame.Position)
			    	game["Run Service"].Heartbeat:Wait()
			    end
			end
		end
	end
end)