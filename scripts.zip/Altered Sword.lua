loadstring(game:HttpGet("https://raw.githubusercontent.com/Alpha-404/NAP-Client-Reanimate/main/Reanimate.lua"))()
local char = game:GetService("Players").LocalPlayer.Character
local p = game:GetService("Players").LocalPlayer
char.Torso:WaitForChild("NAP Client Reanim")
local state = "Idle"
local slashing = false

local RUSSIA = Instance.new("Sound", char["Torso"])
RUSSIA.SoundId = "rbxassetid://5315685213"
RUSSIA.Volume = 10
RUSSIA.Looped = true
RUSSIA:Play()

function Animate(joint, cframe, speed)
    game:GetService("TweenService"):Create(joint, TweenInfo.new(speed), {['CFrame'] = cframe}):Play()
end

local char = game:GetService("Players").LocalPlayer.Character
local Sniper = char["ShadowBladeMasterAccessory"]
local att0 = Instance.new("Attachment",Sniper.Handle)
att0.CFrame = CFrame.new(1.29999995, 2.20000005, 0, -1.03333626e-07, -0.681998372, 0.7313537, 6.39370228e-08, 0.7313537, 0.681998372, -1, 1.17233938e-07, -3.19684865e-08)
att0.Name = "SwordHook"

local att1 = Instance.new("Attachment",char["Right Arm"])

local ap = Instance.new("AlignPosition",Sniper.Handle)
ap.Attachment0 = att0
ap.Attachment1 = att1
ap.RigidityEnabled = true 

local ao = Instance.new("AlignOrientation",Sniper.Handle) 
ao.Attachment0 = att0
ao.Attachment1 = att1
ao.RigidityEnabled = true

Sniper.Handle.AccessoryWeld:Destroy()

Sniper.Handle:GetPropertyChangedSignal("LocalTransparencyModifier"):Connect(function()
	Sniper.Handle.LocalTransparencyModifier = Sniper.Handle.Transparency
end)
Sniper.Handle.LocalTransparencyModifier = Sniper.Handle.Transparency

char.Humanoid.Running:Connect(function(gay)
	if gay > 0 then
		state = "Walk"
	else
		state = "Idle"
	end
end)

p:GetMouse().Button1Down:Connect(function()
    if slashing == false then
       slashing = true
        Animate(char["Right Arm"].RA, CFrame.new(-1, 0.5, -0.800000012, 0.492403835, 0.852868557, -0.173648179, 0.508204639, -0.119763881, 0.852868557, 0.70658797, -0.50820452, -0.492403924), 0.3)
	    wait(0.3)
	    Animate(char["Right Arm"].RA, CFrame.new(-1, 1.5, -0.300000012, 0.492403835, 0.852868557, -0.173648179, -0.866025448, 0.49999994, 0, 0.0868240818, 0.150383741, 0.98480773), 0.1)
	    wait(0.25)
	    Animate(char["Right Arm"].RA, CFrame.new(-1.5, 0, 0, 0.939692676, -1.90757756e-08, 0.342020154, 0.116977766, 0.939692676, -0.321393788, -0.321393788, 0.342020094, 0.88302230), 0.3)
	    wait(0.3)
	    slashing = false
    end
end)

while true do
	if state == "Idle" and slashing == false then
	    Animate(char["Torso"].TORSO, CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),1)
	    Animate(char["Left Arm"].LA, CFrame.new(1.5, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),1)
	    Animate(char["Left Leg"].LL, CFrame.new(0.5, 2, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),1)
	    Animate(char["Right Leg"].RL, CFrame.new(-0.5, 2, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1), 1)
		Animate(char["Right Arm"].RA, CFrame.new(-1.5, 0, 0, 0.939692616, -1.90758538e-08, 0.342020124, 0.0593911894, 0.98480773, -0.163175911, -0.336824059, 0.173648179, 0.925416529), 1)
		wait(1)
		Animate(char["Right Arm"].RA, CFrame.new(-1.5, 0, 0, 0.939692676, -1.90757756e-08, 0.342020154, 0.116977766, 0.939692676, -0.321393788, -0.321393788, 0.342020094, 0.88302230), 1)
		wait(1)
	elseif state == "Walk" and slashing == false then
	    Animate(char["Torso"].TORSO, CFrame.new(0, 0, 0, 1, 0, 0, 0, 0.98480773, -0.173648179, 0, 0.173648179, 0.98480773), 0.3)
		Animate(char["Right Arm"].RA, CFrame.new(-1.5, 0.200000003, 0.300000012, 1, 0, -0, 0, 0.766044438, 0.642787576, 0, -0.642787576, 0.766044438), 0.3)
		Animate(char["Left Arm"].LA, CFrame.new(1.5, 0.400000006, -0.400000006, 1, 0, 0, 0, 0.766044438, -0.642787576, 0, 0.642787576, 0.766044438), 0.3)
		Animate(char["Left Leg"].LL, CFrame.new(0.5, 2, 0.100000001, 1, 0, -0, 0, 0.939692616, 0.342020124, 0, -0.342020124, 0.939692616), 0.3)
		Animate(char["Right Leg"].RL, CFrame.new(-0.5, 2, 0.300000012, 1, 0, 0, 0, 0.939692616, -0.342020124, 0, 0.342020124, 0.939692616), 0.3)
		wait(0.3)
		Animate(char["Right Arm"].RA, CFrame.new(-1.5, 0.100000001, -0.300000012, 1, 0, 0, 0, 0.766044438, -0.642787576, 0, 0.642787576, 0.766044438), 0.3)
		Animate(char["Left Arm"].LA, CFrame.new(1.5, 0.200000003, 0.300000012, 1, 0, -0, 0, 0.766044438, 0.642787576, 0, -0.642787576, 0.766044438), 0.3)
		Animate(char["Left Leg"].LL, CFrame.new(0.5, 2, 0.300000012, 1, 0, 0, 0, 0.939692616, -0.342020124, 0, 0.342020124, 0.939692616), 0.3)
		Animate(char["Right Leg"].RL, CFrame.new(-0.5, 2, 0.100000001, 1, 0, -0, 0, 0.939692616, 0.342020124, 0, -0.342020124, 0.939692616), 0.3)
		wait(0.3)
	end
	wait()
end