--//SpeedRacer // Guardian Of The Scripts


loadstring(game:HttpGet("https://raw.githubusercontent.com/Alpha-404/NAP-Client-Reanimate/main/Reanimate.lua"))()
local char = game:GetService("Players").LocalPlayer.Character
local p = game:GetService("Players").LocalPlayer
char.Torso:WaitForChild("NAP Client Reanim")
local S = Instance.new("Sound", char.HumanoidRootPart)
local state = "Idle"
S.SoundId = "rbxassetid://2435339444"
S.Volume = 10
S.Looped = true
S:Play()
char:FindFirstChildOfClass("Humanoid").WalkSpeed = 150
local UserInputService = game:GetService("UserInputService")

if char:FindFirstChild("Meshes/SniperAccessory") then
	local Sniper = char["Meshes/SniperAccessory"]
	local att0 = Instance.new("Attachment",Sniper.Handle)
	att0.Orientation = Vector3.new(143, 90, 0)
	att0.Position = Vector3.new(1, -2.4, 0)
	att0.Name = "SniperHook"

	local att1 = Instance.new("Attachment",char["Right Arm"])

	local ap = Instance.new("AlignPosition",Sniper.Handle)
	ap.Attachment0 = att0
	ap.Attachment1 = att1
	ap.RigidityEnabled = true 


	local ao = Instance.new("AlignOrientation",Sniper.Handle) 
	ao.Attachment0 = att0
	ao.Attachment1 = att1
	ao.RigidityEnabled = true

	Sniper.Handle.AccessoryWeld:Destroy()
end

local x = UserInputService.InputBegan:Connect(function(null, gay)
	if gay then return end
	if UserInputService:IsKeyDown(Enum.KeyCode.E) then
		if game:GetService("Players").LocalPlayer:GetMouse().Target == nil then return end
		game:GetService("TweenService"):Create(char["Right Arm"].RA, TweenInfo.new(0.2), {['CFrame'] = CFrame.new(-1.5, 1, 0.5, 1, 0, 0, 0, -4.37113883e-08, 1, 0, -1, -4.37113883e-08)}):Play()
		wait(0.2)
		game:GetService("TweenService"):Create(char["Right Arm"].RA, TweenInfo.new(0.2), {['CFrame'] = CFrame.new(-1.5, 1, 0.5, 1, 0, 0, 0, -0.50000006, 0.866025388, 0, -0.866025388, -0.50000006)}):Play()
		wait(0.2)
		game:GetService("TweenService"):Create(char["Right Arm"].RA, TweenInfo.new(0.4), {['CFrame'] = CFrame.new(-1.5, 0, 0, 0.939692616, -7.0012609e-09, 0.342020124, 0.116977781, 0.939692616, -0.321393788, -0.321393788, 0.342020124, 0.883022189)}):Play()
	end
end)

spawn(function()
	p.CharacterAdded:Wait()
	x:Disconnect()
	bp:Destroy()
end)

game:GetService("TweenService"):Create(char["Right Arm"].RA, TweenInfo.new(0.4), {['CFrame'] = CFrame.new(-1.5, 0, 0, 0.939692616, -7.0012609e-09, 0.342020124, 0.116977781, 0.939692616, -0.321393788, -0.321393788, 0.342020124, 0.883022189)}):Play()

while true do
    local torvel = (char.HumanoidRootPart.Velocity * Vector3.new(1, 0, 1)).magnitude
	if torvel < 1 then
		game:GetService("TweenService"):Create(char["Torso"].TORSO, TweenInfo.new(0.8), {['CFrame'] = CFrame.new(0, -8, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1)}):Play()
		game:GetService("TweenService"):Create(char["Left Arm"].LA, TweenInfo.new(0.8), {['CFrame'] = CFrame.new(1.5, 1.5, 0, 1, 0, 0, 0, -1, 8.74227766e-08, 0, -8.74227766e-08, -1)}):Play()
		game:GetService("TweenService"):Create(char["Left Leg"].LL, TweenInfo.new(0.8), {['CFrame'] = CFrame.new(0.5, 2, 0, 1, 0, -0, 0, 0.98480773, 0.173648179, 0, -0.173648179, 0.98480773)}):Play()
		game:GetService("TweenService"):Create(char["Right Leg"].RL, TweenInfo.new(0.8), {['CFrame'] = CFrame.new(-0.5, 2, 0, 1, 0, 0, 0, 0.939692616, -0.342020124, 0, 0.342020124, 0.939692616)}):Play()
		wait(0.8)
		game:GetService("TweenService"):Create(char["Left Leg"].LL, TweenInfo.new(0.8), {['CFrame'] = CFrame.new(0.5, 2, 0, 1, 0, 0, 0, 0.98480773, -0.173648179, 0, 0.173648179, 0.98480773)}):Play()
		game:GetService("TweenService"):Create(char["Left Arm"].LA, TweenInfo.new(0.8), {['CFrame'] = CFrame.new(1.5, 1.5, 0, 1, 0, 0, 0, -0.939692616, 0.342020214, 0, -0.342020214, -0.939692616)}):Play()
		game:GetService("TweenService"):Create(char["Right Leg"].RL, TweenInfo.new(0.8), {['CFrame'] = CFrame.new(-0.5, 2, 0, 1, 0, -0, 0, 0.965925813, 0.258819044, 0, -0.258819044, 0.965925813)}):Play()
		game:GetService("TweenService"):Create(char["Torso"].TORSO, TweenInfo.new(0.8), {['CFrame'] = CFrame.new(0, -5, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1)}):Play()
		wait(0.8)
	elseif torvel > 1 then
		game:GetService("TweenService"):Create(char["Torso"].TORSO, TweenInfo.new(0.4), {['CFrame'] = CFrame.new(0, 0, -8, 1, 0, 0, 0, -4.37113883e-08, -1, 0, 1, -4.37113883e-08)}):Play()
		game:GetService("TweenService"):Create(char["Left Arm"].LA, TweenInfo.new(0.4), {['CFrame'] = CFrame.new(1.5, 1.5, 0, 1, 0, 0, 0, -1, 8.74227766e-08, 0, -8.74227766e-08, -1)}):Play()
		game:GetService("TweenService"):Create(char["Right Arm"].RA, TweenInfo.new(0.4), {['CFrame'] = CFrame.new(-1.5, 0, 0, 0.939692616, -7.0012609e-09, 0.342020124, 0.116977781, 0.939692616, -0.321393788, -0.321393788, 0.342020124, 0.883022189)}):Play()
		game:GetService("TweenService"):Create(char["Left Leg"].LL, TweenInfo.new(0.4), {['CFrame'] = CFrame.new(0.5, 2, 0, 1, 0, 0, 0, 0.99619472, -0.087155737, 0, 0.087155737, 0.99619472)}):Play()
		game:GetService("TweenService"):Create(char["Right Leg"].RL, TweenInfo.new(0.4), {['CFrame'] = CFrame.new(-0.5, 2, 0, 1, 0, -0, 0, 0.99619472, 0.087155737, 0, -0.087155737, 0.99619472)}):Play()
		wait(0.4)
		game:GetService("TweenService"):Create(char["Left Leg"].LL, TweenInfo.new(0.4), {['CFrame'] = CFrame.new(0.5, 2, 0, 1, 0, -0, 0, 0.99619472, 0.087155737, 0, -0.087155737, 0.99619472)}):Play()
		game:GetService("TweenService"):Create(char["Left Arm"].LA, TweenInfo.new(0.4), {['CFrame'] = CFrame.new(1.5, 1.5, 0, 1, 0, 0, 0, -0.939692616, 0.342020214, 0, -0.342020214, -0.939692616)}):Play()
		game:GetService("TweenService"):Create(char["Right Leg"].RL, TweenInfo.new(0.4), {['CFrame'] = CFrame.new(-0.5, 2, 0, 1, 0, 0, 0, 0.99619472, -0.087155737, 0, 0.087155737, 0.99619472)}):Play()
		game:GetService("TweenService"):Create(char["Torso"].TORSO, TweenInfo.new(0.4), {['CFrame'] = CFrame.new(0, 0, -5, 1, 0, 0, 0, -4.37113883e-08, -1, 0, 1, -4.37113883e-08)}):Play()
		wait(0.4)
	end
end