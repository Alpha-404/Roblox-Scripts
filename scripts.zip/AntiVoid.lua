local p = game:GetService("Players").LocalPlayer
local c = p.Character
local freefall = false
local saved

p.CharacterAdded:Connect(function()
	p.Character:WaitForChild("Humanoid").FreeFalling:Connect(function()
		local root = p.Character.HumanoidRootPart or p.Character.Torso or p.Character.UpperTorso
		freefall = true
		while freefall do
			if root.Position.Y <= workspace.FallenPartsDestroyHeight + 35 then
				for i,v in pairs(p.Character:GetDescendants()) do
					if v:IsA("BasePart") then
						v.Velocity = Vector3.new(0,0,0)
					end
				end
				root.CFrame = saved
			end
			wait()
		end
	end)
	p.Character.Humanoid.Running:Connect(function(sped)
		local root = p.Character.HumanoidRootPart or p.Character.Torso or p.Character.UpperTorso
		if sped >= 0 then
			saved = root.CFrame
		end
	end)
end)
local origpos = c.HumanoidRootPart.CFrame or c.Torso.CFrame or c.UpperTorso.CFrame
c:BreakJoints()
p.CharacterAdded:Wait()
wait(0.2)
local root = p.Character.HumanoidRootPart or p.Character.Torso or p.Character.UpperTorso
root.CFrame = origpos