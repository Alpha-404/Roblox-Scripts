local UserInputService = game:GetService("UserInputService")
local p = game:GetService("Players").LocalPlayer
local mouse = p:GetMouse()
UserInputService.InputBegan:Connect(function(key, gay)
    if gay then return end
	if key.keyCode == Enum.KeyCode.F then
	    if game:GetService('Players').LocalPlayer:GetMouse().Target ~= nil then
	        if mouse.Target.Parent:FindFirstChild("Humanoid") then
	            local idiot = mouse.Target.Parent
	            workspace:WaitForChild("goodcar" or "goodcar2").CFrame = idiot.HumanoidRootPart.CFrame
	        end
	    end
	end
end)