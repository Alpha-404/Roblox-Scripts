local KeyFrames = {
   {
      K = Keyframe,
      Poses = {
         Head = {
            CF = CFrame.new(0, -1.3351440429688e-05, 4.7683715820313e-07, 1, 0, 0, 0, 0.7368124127388, 0.67609709501266, 0, -0.67609709501266, 0.7368124127388),
            EasingDirection = Enum.PoseEasingDirection.In,
            EasingStyle = Enum.PoseEasingStyle.Linear
         },
         HumanoidRootPart = {
            CF = CFrame.new(0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0, 1),
            EasingDirection = Enum.PoseEasingDirection.In,
            EasingStyle = Enum.PoseEasingStyle.Linear
         },
         Torso = {
            CF = CFrame.new(0, 0, -2.3399999141693, 1, 0, 0, 0, 0.80044192075729, -0.59941035509109, 0, 0.59941035509109, 0.80044192075729),
            EasingDirection = Enum.PoseEasingDirection.In,
            EasingStyle = Enum.PoseEasingStyle.Linear
         },
         ["Left Arm"] = {
            CF = CFrame.new(-0.24811244010925, 0.18585133552551, -0.25000095367432, 0.51088845729828, 0.53418827056885, -0.6735246181488, -0.57096314430237, -0.37485572695732, -0.73039966821671, -0.64264577627182, 0.75771063566208, 0.11349235475063),
            EasingDirection = Enum.PoseEasingDirection.In,
            EasingStyle = Enum.PoseEasingStyle.Linear
         },
         ["Left Leg"] = {
            CF = CFrame.new(-8.5830688476563e-06, -1.9073486328125e-06, 0, 0.36012053489685, -0.93290549516678, 0.00045688188401982, 0.93290561437607, 0.36012044548988, -0.00017639908764977, 3.1175837023056e-08, 0.00048975256504491, 0.99999988079071),
            EasingDirection = Enum.PoseEasingDirection.In,
            EasingStyle = Enum.PoseEasingStyle.Linear
         },
         ["Right Arm"] = {
            CF = CFrame.new(0.36019682884216, 0.26973867416382, 1.9073486328125e-06, -0.7535902261734, -0.65622621774673, 0.03832658007741, 0.65726906061172, -0.75310397148132, 0.028829021379352, 0.0099455360323191, 0.046916138380766, 0.99884909391403),
            EasingDirection = Enum.PoseEasingDirection.In,
            EasingStyle = Enum.PoseEasingStyle.Linear
         },
         ["Right Leg"] = {
            CF = CFrame.new(-0.012521743774414, -0.38446009159088, 0, 0.090428858995438, 0.99590265750885, -3.9758788261679e-08, -0.99590277671814, 0.090428799390793, -4.3532317306472e-08, -3.9758631942277e-08, 4.3532459415019e-08, 1),
            EasingDirection = Enum.PoseEasingDirection.In,
            EasingStyle = Enum.PoseEasingStyle.Linear
         }
      },
      Time = 0
   },
   {
      K = Keyframe,
      Poses = {
         Head = {
            CF = CFrame.new(0, -0.44025731086731, 0.32967567443848, 1, 0, 0, 0, 0.73681235313416, 0.6760972738266, 0, -0.6760972738266, 0.73681235313416),
            EasingDirection = Enum.PoseEasingDirection.In,
            EasingStyle = Enum.PoseEasingStyle.Linear
         },
      },
      Time = 0.16666667163372
   },
   {
      K = Keyframe,
      Poses = {
         Head = {
            CF = CFrame.new(0, -1.3351440429688e-05, 4.7683715820313e-07, 1, 0, 0, 0, 0.7368124127388, 0.67609709501266, 0, -0.67609709501266, 0.7368124127388),
            EasingDirection = Enum.PoseEasingDirection.In,
            EasingStyle = Enum.PoseEasingStyle.Linear
         },
      },
      Time = 0.30000001192093
   }
}
loadstring(game:HttpGet('https://raw.githubusercontent.com/Alpha-404/NC-REANIM-V2/main/Reanimate.lua'))()

local Character = workspace:WaitForChild('Rig')
local Motors = {}
local Normals = {}

for i,v in pairs(Character:GetDescendants()) do
	if v:IsA("Motor6D") and v.Part0 and v.Part1  then
		Motors[tostring(v.Part1)] = v
		Normals[tostring(v.Part1)] = v.Transform
	end
end 

local function poseTweenInfo(t,s,g)
	local s = tostring(s)
	local g = tostring(g)
	local s = string.split(s,"Enum.PoseEasingStyle.")
	local g = string.split(g,"Enum.PoseEasingDirection.")
	local s = s[2]
	local g = g[2]
	local s = Enum.EasingStyle[s]
	local g = Enum.EasingDirection[g]
	return TweenInfo.new(t,s,g)
end

while wait() do
	for i,Keyframe in pairs(KeyFrames) do
		local LastKeyframe = KeyFrames[#KeyFrames-1] or Keyframe
		for PoseName,Pose in pairs(Keyframe.Poses) do
			local Inst = Motors[tostring(PoseName)]
			if Inst and Inst.Name ~= "HumanoidRootPart" then
				local waitTime = Keyframe.Time
				local PoseTween = game:GetService("TweenService"):Create(Motors[tostring(PoseName)],poseTweenInfo(waitTime,Pose.EasingStyle,Pose.EasingDirection),{Transform = Pose.CF})

				PoseTween:Play()
			end
		end
		wait(Keyframe.Time)
	end

	for i,v in pairs(Motors) do
		game:GetService("TweenService"):Create(v,TweenInfo.new(),{Transform = Normals[tostring(i)]}):Play()
	end
end