loadstring(game:HttpGet("https://pastebin.com/raw/GqEA7LLs"))();
game:GetService("CoreGui").ScreenGui.Main.Title:Destroy()