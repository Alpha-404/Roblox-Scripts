local c = game:GetService("Players").LocalPlayer.Character
local h = c.BuurBuddyAccessory
local force = Instance.new("BodyPosition", h.Handle)
h.Handle.AccessoryWeld:Destroy()
memes = game:GetService("RunService").RenderStepped:Connect(function()
    force.Position = c.HumanoidRootPart.Position + Vector3.new(2,-2,0)
    h.Handle.Orientation = c.HumanoidRootPart.Orientation
end)
c.Humanoid.Died:Connect(function() memes:Disconnect() script:Destroy() end)