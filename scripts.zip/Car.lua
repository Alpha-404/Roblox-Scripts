game.Players.LocalPlayer.Character.Humanoid.WalkSpeed = 80
game.Players.LocalPlayer.Character.Humanoid.JumpPower = 0.0001
Float_Height = "-1.1"
AnimationId = "129342287"
local Anim = Instance.new("Animation")
Anim.AnimationId = "rbxassetid://"..AnimationId
local AnimLoader = game.Players.LocalPlayer.Character.Humanoid:LoadAnimation(Anim)
AnimLoader:Play()
AnimLoader:AdjustSpeed(1)
for idkforvar1, Car in pairs(game.Players.LocalPlayer.Character:GetDescendants()) do
	if Car.ClassName == "Part" then
		Car.CustomPhysicalProperties = PhysicalProperties.new(0, 0, 0)
	end
end
local L_3_ = 1
G = game
_ = wait
p = G:GetService("Players").LocalPlayer.Character
p:FindFirstChild("Humanoid").HipHeight = Float_Height
_(1.5)
t = .4
for L_6_forvar1 = 1, L_3_ do
	repeat
		p:FindFirstChild("Humanoid").HipHeight = Float_Height - n
		_(t)
		p:FindFirstChild("Humanoid").HipHeight = Float_Height + n
		_(t)
	until p:FindFirstChild("Humanoid").Health == 0
end