local plr = game:GetService("Players").LocalPlayer
local char = plr.Character
local NL

NL = game:GetService("RunService").Stepped:Connect(function()
	if plr.Character ~= nil then
		for _, child in pairs(char:GetDescendants()) do
			if child:IsA("BasePart") and child.CanCollide == true then
				child.CanCollide = false
			end
		end
	end
end)

plr.CameraMinZoomDistance = math.huge - math.huge
plr.CameraMaxZoomDistance = math.huge - math.huge

spawn(function()
	plr.CharacterAdded:Wait()
	NL:Disconnect()
end)

if char:FindFirstChildOfClass('Humanoid').RigType == Enum.HumanoidRigType.R15 then
	local att0 = Instance.new("Attachment",char["LowerTorso"])
	att0.Orientation = Vector3.new(-180, 180, 0)
	att0.Position = Vector3.new(0, 1, 0)
	att0.Name = "LT"

	local att1 = Instance.new("Attachment",char["HumanoidRootPart"])

	local ap = Instance.new("AlignPosition",char["HumanoidRootPart"])
	ap.Attachment0 = att0
	ap.Attachment1 = att1
	ap.RigidityEnabled = true 


	local ao = Instance.new("AlignOrientation",char["HumanoidRootPart"]) 
	ao.Attachment0 = att0
	ao.Attachment1 = att1
	ao.RigidityEnabled = true

	char["LowerTorso"].Root:Destroy()
elseif char:FindFirstChildOfClass('Humanoid').RigType == Enum.HumanoidRigType.R6 then
	
	local att0 = Instance.new("Attachment",char["Torso"])
	att0.Orientation = Vector3.new(180, 180, 0)
	att0.Position = Vector3.new(0, 0, 0)
	att0.Name = "TORSO"

	local att1 = Instance.new("Attachment",char["HumanoidRootPart"])

	local ap = Instance.new("AlignPosition",char["HumanoidRootPart"])
	ap.Attachment0 = att0
	ap.Attachment1 = att1
	ap.RigidityEnabled = true 


	local ao = Instance.new("AlignOrientation",char["HumanoidRootPart"]) 
	ao.Attachment0 = att0
	ao.Attachment1 = att1
	ao.RigidityEnabled = true
	
	char["HumanoidRootPart"].RootJoint:Destroy()
else
	print("wtf")
end

game:GetService("StarterGui"):SetCore("SendNotification",{Title="FE Dinnerbone loaded",Text='Made by Terminated Egg#4125',Duration=5})