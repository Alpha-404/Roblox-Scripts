local k = game:GetService("Players").LocalPlayer.Character["Drone Egg"]
k.Handle.AccessoryWeld:Destroy()
local ForceInstance = Instance.new("BodyPosition", k.Handle)

game:GetService("RunService").RenderStepped:Connect(function()
    ForceInstance.Position = game:GetService("Players").LocalPlayer.Character.Head.Position + Vector3.new(0, 3, 0)
	settings().Physics.AllowSleep = false
	setsimulationradius(math.huge*math.huge,math.huge*math.huge)
end)