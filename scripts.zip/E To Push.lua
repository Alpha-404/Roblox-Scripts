getgenv().power = 200

game:GetService("UserInputService").InputBegan:Connect(function(key, gay)
    if gay then return "say no homo bitch" end 
    if key.KeyCode == Enum.KeyCode.E then
        for i=1,getgenv().power do
            game:GetService("Players").LocalPlayer.Backpack.Push.PushEvent:FireServer()
        end
    end
end)