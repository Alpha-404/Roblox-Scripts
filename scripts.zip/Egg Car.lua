if game:GetService("Players").LocalPlayer.Character:FindFirstChild("Egg DogAccessory") and game:GetService("Players").LocalPlayer.Character:FindFirstChild("MeshPartAccessory") then

	local plr = game:GetService("Players").LocalPlayer
	local char = plr.Character
	local egg = char["Egg DogAccessory"]
	local car = char["MeshPartAccessory"]

	egg.Handle.AccessoryWeld:Destroy()
	local att0 = Instance.new("Attachment",egg.Handle)
	att0.Orientation = Vector3.new(0, 180, 0)
	att0.Position = Vector3.new(-5, 1.3, -2.7)

	local att1 = Instance.new("Attachment",char["HumanoidRootPart"])

	local ap = Instance.new("AlignPosition",egg.Handle)
	ap.Attachment0 = att0
	ap.Attachment1 = att1
	ap.RigidityEnabled = true 


	local ao = Instance.new("AlignOrientation",egg.Handle) 
	ao.Attachment0 = att0
	ao.Attachment1 = att1
	ao.RigidityEnabled = true
	
	car.Handle.AccessoryWeld:Destroy()
	local att0 = Instance.new("Attachment",car.Handle)
	att0.Orientation = Vector3.new(0, 0, 0)
	att0.Position = Vector3.new(5, 2, 3)

	local att1 = Instance.new("Attachment",char["HumanoidRootPart"])

	local ap = Instance.new("AlignPosition",car.Handle)
	ap.Attachment0 = att0
	ap.Attachment1 = att1
	ap.RigidityEnabled = true 


	local ao = Instance.new("AlignOrientation",car.Handle) 
	ao.Attachment0 = att0
	ao.Attachment1 = att1
	ao.RigidityEnabled = true
	
end