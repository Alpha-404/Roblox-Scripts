local ScreenGui = Instance.new("ScreenGui")
local Frame = Instance.new("Frame")
local TextLabel = Instance.new("TextLabel")
local fl = Instance.new("TextButton")
local UICorner = Instance.new("UICorner")
local user = Instance.new("TextBox")
local UICorner_2 = Instance.new("UICorner")
local target

local function RS(name)
	return name:gsub('%s+', '') or name
end
local function findplayer(name)
	if name == nil or name == "me" then return p end
	name = RS(name)
	for i, player in pairs(game:GetService('Players'):GetPlayers()) do
		if player.Name:lower():match('^'.. name:lower()) then
			return player
		end
	end
	return nil
end

function findroot(char)
	local rootPart = char:FindFirstChild('HumanoidRootPart') or char:FindFirstChild('Torso') or char:FindFirstChild('UpperTorso')
	return rootPart
end

if syn and syn.protect_gui then
	syn.protect_gui(ScreenGui)
end

ScreenGui.Parent = game:GetService("CoreGui")
ScreenGui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling

Frame.Parent = ScreenGui
Frame.BackgroundColor3 = Color3.fromRGB(33, 33, 33)
Frame.BorderSizePixel = 0
Frame.Position = UDim2.new(0.406143337, 0, 0.33252427, 0)
Frame.Size = UDim2.new(0.205631405, 0, 0.362864077, 0)

TextLabel.Parent = Frame
TextLabel.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
TextLabel.BackgroundTransparency = 1.000
TextLabel.BorderSizePixel = 0
TextLabel.Position = UDim2.new(0, 0, -0.167224079, 0)
TextLabel.Size = UDim2.new(1, 0, 0.167224079, 0)
TextLabel.Font = Enum.Font.SciFi
TextLabel.Text = "EGG GUI"
TextLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
TextLabel.TextScaled = true
TextLabel.TextSize = 14.000
TextLabel.TextWrapped = true

fl.Name = "fl"
fl.Parent = Frame
fl.BackgroundColor3 = Color3.fromRGB(45, 45, 45)
fl.BorderSizePixel = 0
fl.Position = UDim2.new(0.228215784, 0, 0.715719044, 0)
fl.Size = UDim2.new(0.539419115, 0, 0.15384616, 0)
fl.Font = Enum.Font.SciFi
fl.Text = "FLING"
fl.TextColor3 = Color3.fromRGB(255, 255, 255)
fl.TextSize = 20.000
fl.MouseButton1Click:Connect(function()
	if target ~= nil then
		if game:GetService("Players").LocalPlayer.Character:FindFirstChild("Egg DogAccessory") then
			game:GetService("Players").LocalPlayer.Character:FindFirstChild("Egg DogAccessory").Parent = workspace
		end
		local doggo = workspace["Egg DogAccessory"]
		local tp = findroot(target.Character).CFrame
		local flinging = true
		local tring = Instance.new("BodyAngularVelocity",doggo.Handle)
		local kan = Instance.new("Sound", doggo.Handle)
		kan.Volume = 10
		kan.Looped = true
		kan.TimePosition = 0
		kan.PlaybackSpeed = 1
		kan.Pitch = 1
		kan.SoundId = "rbxassetid://3145784977"
		kan.Name = "bang"
		kan:Play()
		tring.MaxTorque = Vector3.new(math.huge,math.huge,math.huge)
		tring.P = 1000000000000000000000000000
		tring.AngularVelocity = Vector3.new(10000,10000,10000)
		spawn(function()
			while flinging do
				wait()
				doggo.Handle.CFrame = tp
			end
		end)
		wait(2)
		flinging = false
		tring:Destroy()
		kan:Destroy()
	end
end)

UICorner.Parent = fl

user.Name = "user"
user.Parent = Frame
user.BackgroundColor3 = Color3.fromRGB(45, 45, 45)
user.BorderSizePixel = 0
user.Position = UDim2.new(0.136929467, 0, 0.210702345, 0)
user.Size = UDim2.new(0.721991718, 0, 0.143812716, 0)
user.Font = Enum.Font.SciFi
user.PlaceholderText = "Player Name Here"
user.Text = ""
user.TextColor3 = Color3.fromRGB(255, 255, 255)
user.TextSize = 14.000
user.FocusLost:Connect(function()
	local rkegoejrgoei = findplayer(user.Text)
	user.Text = rkegoejrgoei.Name
	target = rkegoejrgoei
end)

UICorner_2.Parent = user

local L_1_ = game:GetService("UserInputService")
function drag(L_2_arg1)
	dragToggle = nil
	local dragSpeed = 0.23
	dragInput = nil
	dragStart = nil
	local dragPos = nil
	function updateInput(L_3_arg1)
		local Delta = L_3_arg1.Position - dragStart
		local Position = UDim2.new(startPos.X.Scale, startPos.X.Offset + Delta.X, startPos.Y.Scale, startPos.Y.Offset + Delta.Y)
		game:GetService("TweenService"):Create(L_2_arg1, TweenInfo.new(0.25), {
			Position = Position
		}):Play()
	end
	L_2_arg1.InputBegan:Connect(function(L_4_arg1)
		if (L_4_arg1.UserInputType == Enum.UserInputType.MouseButton1 or L_4_arg1.UserInputType == Enum.UserInputType.Touch) and L_1_:GetFocusedTextBox() == nil then
			dragToggle = true
			dragStart = L_4_arg1.Position
			startPos = L_2_arg1.Position
			L_4_arg1.Changed:Connect(function()
				if L_4_arg1.UserInputState == Enum.UserInputState.End then
					dragToggle = false
				end
			end)
		end
	end)
	L_2_arg1.InputChanged:Connect(function(L_5_arg1)
		if L_5_arg1.UserInputType == Enum.UserInputType.MouseMovement or L_5_arg1.UserInputType == Enum.UserInputType.Touch then
			dragInput = L_5_arg1
		end
	end)
	game:GetService("UserInputService").InputChanged:Connect(function(L_6_arg1)
		if L_6_arg1 == dragInput and dragToggle then
			updateInput(L_6_arg1)
		end
	end)
end
drag(Frame)