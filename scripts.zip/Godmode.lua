local p = game:GetService("Players").LocalPlayer
local c = p.Character
local temp = Instance.new("Model", workspace)
Instance.new("Humanoid",temp)
temp.Name = "Fred"
p.Character = temp
if c:FindFirstChildOfClass("Humanoid"):FindFirstChild("Animator") then
	c:FindFirstChildOfClass("Humanoid").Animator.Parent = temp.Humanoid
end
wait()
local rig
if c:FindFirstChildOfClass("Humanoid").RigType == Enum.HumanoidRigType.R15 then
	rig = "R15"
else
	rig = "R6"
end
local Reset = Instance.new("BindableEvent")
Reset.Event:Connect(function()
	game:GetService("StarterGui"):SetCore("ResetButtonCallback", true)
	Reset:Destroy()
	local m = Instance.new("Model", workspace)
	m.Name = "UwU"
	local h = Instance.new("Humanoid", m)
	p.Character:Destroy()
	wait()
	p.Character = m
	wait()
	h.Health = 0
	p.ChildAdded:Wait()
	m:Destroy()
end)
game:GetService("StarterGui"):SetCore("ResetButtonCallback", Reset)
c.Humanoid:Destroy()
local humanoid = Instance.new("Humanoid", c)
humanoid.RequiresNeck = false
humanoid.DisplayDistanceType = Enum.HumanoidDisplayDistanceType.None
humanoid.HealthDisplayDistance = Enum.HumanoidHealthDisplayType.AlwaysOff
if rig == "R15" then
	humanoid.RigType = Enum.HumanoidRigType.R15
	humanoid.HipHeight = 2.19
else
	humanoid.RigType = Enum.HumanoidRigType.R6
end
p.Character = c
workspace.CurrentCamera.CameraSubject = c
if c:FindFirstChild("Animate") then
	c.Animate.Disabled = true
	c.Animate.Disabled = false
end
wait()
temp:Destroy()