loadstring(game:HttpGet('https://raw.githubusercontent.com/Alpha-404/NC-REANIM-V2/main/V2.5.lua'))()
game:GetService("Players").LocalPlayer.Character.Head:Destroy()