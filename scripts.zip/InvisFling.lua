local char = game:GetService("Players").LocalPlayer.Character
local idk = false

local hrp = char.TurtleNeck

hrp.Handle.Transparency = 0.5
hrp.Handle.SpecialMesh:Destroy()

hrp.Parent = workspace

local OCF = char.HumanoidRootPart.CFrame

local bp = Instance.new("BodyPosition", hrp.Handle)
bp.D = 60
bp.MaxForce = Vector3.new(math.huge,math.huge,math.huge)
bp.Position = char.HumanoidRootPart.Position + Vector3.new(0, 15, 0)
wait(0.1)
flinger = Instance.new("BodyAngularVelocity",hrp.Handle)
flinger.MaxTorque = Vector3.new(math.huge,math.huge,math.huge)
flinger.P = 1000000000000000000000000000
flinger.AngularVelocity = Vector3.new(10000,10000,10000)
hrp.Handle.CanCollide = false

char.HumanoidRootPart.CFrame = OCF

--------------------------------------------------------------

local b = game:GetService("RunService").Stepped:Connect(function()
	if game:GetService("Players").LocalPlayer.Character ~= nil and idk == false then
		bp.Position = char["HumanoidRootPart"].Position
	end
end)
local f = game:GetService("UserInputService").InputBegan:Connect(function(key, gay)
	if gay then return end
	if key.KeyCode == Enum.KeyCode.R then
	    if game:GetService("Players").LocalPlayer:GetMouse().Target == nil then return end
		idk = true
		bp.Position = game:GetService("Players").LocalPlayer:GetMouse().Hit.Position
		wait(0.5)
		idk = false
	end
end)

game:GetService("Players").LocalPlayer.CharacterAdded:Wait()
b:Disconnect()
f:Disconnect()