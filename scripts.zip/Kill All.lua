local p = game:GetService("Players").LocalPlayer
for i,v in pairs(p.Character:GetDescendants()) do
	if v:IsA("Tool") then
		local a = Instance.new("SelectionBox",v.Handle)
		a.Name = "SelectionBoxCreated"
		a.Adornee = v.Handle
		a.Color3 = Color3.new(255, 0, 0)
		v.Handle.Massless = true
		v.Handle.Size = Vector3.new(math.huge,math.huge,math.huge)
		v.GripPos = Vector3.new(0,0,0)
		p.Character.Humanoid:UnequipTools()
		wait(0.5)
		p.Character.Humanoid:EquipTool(v)
	end
end