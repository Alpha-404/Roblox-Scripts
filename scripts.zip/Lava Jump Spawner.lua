local speed = 5



local bred = game:GetService("Players").LocalPlayer.Character.Backuette

bred.Handle.SpecialMesh:Destroy()
bred.Parent = workspace
local bp = Instance.new("BodyPosition", bred.Handle)
bp.MaxForce = Vector3.new(math.huge*math.huge,math.huge*math.huge,math.huge*math.huge)
bp.Position = game:GetService("Players").LocalPlayer.Character.HumanoidRootPart.Position + Vector3.new(0,-1.8, 0)
local rot = Instance.new("BodyAngularVelocity",bred.Handle)
rot.MaxTorque = Vector3.new(math.huge,math.huge,math.huge)
rot.P = 10
rot.AngularVelocity = Vector3.new(0,speed,0)
local cf = Instance.new("BodyGyro", bred.Handle)
cf.MaxTorque = Vector3.new(math.huge*math.huge,0,math.huge*math.huge)
cf.CFrame = game:GetService("Players").LocalPlayer.Character.HumanoidRootPart.CFrame
game:GetService("Players").LocalPlayer.Character:ClearAllChildren()

wait(0.5)

game:GetService("Players").LocalPlayer.Character:BreakJoints()
game:GetService("Players").LocalPlayer.CharacterAdded:Wait()
wait(1)
local bred2 = game:GetService("Players").LocalPlayer.Character:WaitForChild("Backuette")
game:GetService("Players").LocalPlayer.Character.Backuette:WaitForChild("Handle")
bred2.Handle.SpecialMesh:Destroy()
bred2.Parent = workspace
local att0 = Instance.new("Attachment",bred2.Handle)
att0.Orientation = Vector3.new(0, 0, 0)
att0.Position = Vector3.new(6, -0, 0)
att0.Name = "BredLongYay"

local att1 = Instance.new("Attachment",bred.Handle)

local ap = Instance.new("AlignPosition",bred2.Handle)
ap.Attachment0 = att0
ap.Attachment1 = att1
ap.RigidityEnabled = true 

local ao = Instance.new("AlignOrientation",bred2.Handle) 
ao.Attachment0 = att0
ao.Attachment1 = att1
ao.RigidityEnabled = true

wait(0.5)

game:GetService("Players").LocalPlayer.Character:BreakJoints()
game:GetService("Players").LocalPlayer.CharacterAdded:Wait()

wait(1)

local bred3 = game:GetService("Players").LocalPlayer.Character:WaitForChild("Backuette")
game:GetService("Players").LocalPlayer.Character.Backuette:WaitForChild("Handle")

bred3.Handle.SpecialMesh:Destroy()
bred3.Parent = workspace

local att0 = Instance.new("Attachment",bred3.Handle)
att0.Orientation = Vector3.new(0, 0, 0)
att0.Position = Vector3.new(-6, -0, 0)
att0.Name = "BredLongYay"

local att1 = Instance.new("Attachment",bred.Handle)

local ap = Instance.new("AlignPosition",bred3.Handle)
ap.Attachment0 = att0
ap.Attachment1 = att1
ap.RigidityEnabled = true 

local ao = Instance.new("AlignOrientation",bred3.Handle) 
ao.Attachment0 = att0
ao.Attachment1 = att1
ao.RigidityEnabled = true