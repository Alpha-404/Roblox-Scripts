loadstring(game:HttpGetAsync("https://pastebin.com/raw/0QfjMKrF"))()
