if not game:IsLoaded() then
	game.Loaded:Wait()
end

if game:GetService("ReplicatedStorage"):FindFirstChild("ExecuteString") then
	local Execution = Instance.new("ScreenGui")
	local NCE = Instance.new("ImageLabel")
	local Topbar = Instance.new("ImageLabel")
	local Close = Instance.new("TextButton")
	local Gradient = Instance.new("Frame")
	local EditorFrame = Instance.new("ImageLabel")
	local Frame = Instance.new("Frame")
	local Source = Instance.new("TextBox")
	local Hide = Instance.new("ImageLabel")
	local Comments_ = Instance.new("TextLabel")
	local Globals_ = Instance.new("TextLabel")
	local Keywords_ = Instance.new("TextLabel")
	local Numbers_ = Instance.new("TextLabel")
	local RemoteHighlight_ = Instance.new("TextLabel")
	local Strings_ = Instance.new("TextLabel")
	local Tokens_ = Instance.new("TextLabel")
	local Lines = Instance.new("TextLabel")
	local Execute = Instance.new("TextButton")
	local TextButton_Roundify_4px = Instance.new("ImageLabel")
	local Clear = Instance.new("TextButton")
	local TextButton_Roundify_4px_2 = Instance.new("ImageLabel")
	local R6 = Instance.new("TextButton")
	local TextButton_Roundify_4px_3 = Instance.new("ImageLabel")
	local Circle = Instance.new("ImageLabel")
	local Respawn = Instance.new("TextButton")
	local TextButton_Roundify_4px_4 = Instance.new("ImageLabel")
	local Antiban = Instance.new("TextButton")
	local TextButton_Roundify_4px_5 = Instance.new("ImageLabel")
	local Status = Instance.new("TextLabel")
	local Injected = Instance.new("TextLabel")
	local SECURE_LOAD = "8881"
	local ReplicatedStorage = game:GetService("ReplicatedStorage")

	if syn and syn.protect_gui then
		syn.protect_gui(Execution)
	end

	function cmd(args, player)
		ReplicatedStorage.Command:FireServer(args, player, "8881")
	end

	local Run = function(...)
		local Arguments = {...}
		return function() ReplicatedStorage.ExecuteString:InvokeServer(SECURE_LOAD, unpack(Arguments)) end
	end


	Execution.Name = "Execution"
	Execution.Parent = game:GetService("CoreGui")
	Execution.ResetOnSpawn = false

	NCE.Name = "NCE"
	NCE.Parent = Execution
	NCE.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
	NCE.BackgroundTransparency = 1.000
	NCE.ClipsDescendants = true
	NCE.Position = UDim2.new(0.291995406, 0, 0.328596026, 0)
	NCE.Size = UDim2.new(0, 487, 0, 282)
	NCE.Image = "rbxassetid://3570695787"
	NCE.ImageColor3 = Color3.fromRGB(34, 34, 34)
	NCE.ScaleType = Enum.ScaleType.Slice
	NCE.SliceCenter = Rect.new(100, 100, 100, 100)
	NCE.SliceScale = 0.040

	Topbar.Name = "Topbar"
	Topbar.Parent = NCE
	Topbar.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
	Topbar.BackgroundTransparency = 1.000
	Topbar.Position = UDim2.new(0.000967919827, 0, -0.00204083323, 0)
	Topbar.Size = UDim2.new(0, 487, 0, 28)
	Topbar.Image = "rbxassetid://3570695787"
	Topbar.ImageColor3 = Color3.fromRGB(49, 49, 49)
	Topbar.ScaleType = Enum.ScaleType.Slice
	Topbar.SliceCenter = Rect.new(100, 100, 100, 100)
	Topbar.SliceScale = 0.040

	Close.Name = "Close"
	Close.Parent = Topbar
	Close.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
	Close.BackgroundTransparency = 10.000
	Close.Position = UDim2.new(0.928403139, 0, -0.121848382, 0)
	Close.Size = UDim2.new(0, 34, 0, 30)
	Close.Font = Enum.Font.SourceSansLight
	Close.Text = "-"
	Close.TextColor3 = Color3.fromRGB(255, 255, 255)
	Close.TextSize = 40.000
	Close.TextWrapped = true

	Gradient.Name = "Gradient"
	Gradient.Parent = Topbar
	Gradient.BackgroundColor3 = Color3.fromRGB(40, 40, 40)
	Gradient.BorderSizePixel = 0
	Gradient.Position = UDim2.new(-0.00108546834, 0, 0.988522887, 0)
	Gradient.Size = UDim2.new(0, 487, 0, 12)

	EditorFrame.Name = "EditorFrame"
	EditorFrame.Parent = NCE
	EditorFrame.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
	EditorFrame.BackgroundTransparency = 1.000
	EditorFrame.Position = UDim2.new(0.0225872695, 0, 0.173758864, 0)
	EditorFrame.Size = UDim2.new(0, 465, 0, 199)
	EditorFrame.Image = "rbxassetid://3570695787"
	EditorFrame.ImageColor3 = Color3.fromRGB(34, 34, 34)
	EditorFrame.ScaleType = Enum.ScaleType.Slice
	EditorFrame.SliceCenter = Rect.new(100, 100, 100, 100)
	EditorFrame.SliceScale = 0.040

	Frame.Parent = EditorFrame
	Frame.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
	Frame.BorderColor3 = Color3.fromRGB(255, 255, 255)
	Frame.BorderSizePixel = 0
	Frame.Position = UDim2.new(0.0387096778, 0, 0.00502512557, 0)
	Frame.Size = UDim2.new(0, 1, 0, 198)

	Source.Name = "Source"
	Source.Parent = EditorFrame
	Source.BackgroundColor3 = Color3.fromRGB(17, 17, 17)
	Source.BackgroundTransparency = 1.000
	Source.Position = UDim2.new(0, 27, 0, 1)
	Source.Size = UDim2.new(0.930083036, 0, 0.994816124, 0)
	Source.ZIndex = 3
	Source.ClearTextOnFocus = false
	Source.Font = Enum.Font.Code
	Source.MultiLine = true
	Source.PlaceholderColor3 = Color3.fromRGB(255, 255, 255)
	Source.Text = "print(\"NAP Client is the best\")"
	Source.TextColor3 = Color3.fromRGB(255, 255, 255)
	Source.TextSize = 15.000
	Source.TextXAlignment = Enum.TextXAlignment.Left
	Source.TextYAlignment = Enum.TextYAlignment.Top

	Hide.Name = "Hide"
	Hide.Parent = Source
	Hide.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
	Hide.BackgroundTransparency = 1.000
	Hide.Position = UDim2.new(-0.00372214313, 0, 0, 0)
	Hide.Size = UDim2.new(0, 379, 0, 189)
	Hide.ZIndex = 6
	Hide.Image = "rbxassetid://3570695787"
	Hide.ImageColor3 = Color3.fromRGB(33, 33, 33)
	Hide.ImageTransparency = 1.000
	Hide.ScaleType = Enum.ScaleType.Slice
	Hide.SliceCenter = Rect.new(100, 100, 100, 100)
	Hide.SliceScale = 0.120

	Comments_.Name = "Comments_"
	Comments_.Parent = Source
	Comments_.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
	Comments_.BackgroundTransparency = 1.000
	Comments_.Size = UDim2.new(1, 0, 1, 0)
	Comments_.ZIndex = 5
	Comments_.Font = Enum.Font.Code
	Comments_.Text = ""
	Comments_.TextColor3 = Color3.fromRGB(59, 200, 59)
	Comments_.TextSize = 15.000
	Comments_.TextXAlignment = Enum.TextXAlignment.Left
	Comments_.TextYAlignment = Enum.TextYAlignment.Top

	Globals_.Name = "Globals_"
	Globals_.Parent = Source
	Globals_.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
	Globals_.BackgroundTransparency = 1.000
	Globals_.Size = UDim2.new(1, 0, 1, 0)
	Globals_.ZIndex = 5
	Globals_.Font = Enum.Font.Code
	Globals_.Text = ""
	Globals_.TextColor3 = Color3.fromRGB(132, 214, 247)
	Globals_.TextSize = 15.000
	Globals_.TextXAlignment = Enum.TextXAlignment.Left
	Globals_.TextYAlignment = Enum.TextYAlignment.Top

	Keywords_.Name = "Keywords_"
	Keywords_.Parent = Source
	Keywords_.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
	Keywords_.BackgroundTransparency = 1.000
	Keywords_.Size = UDim2.new(1, 0, 1, 0)
	Keywords_.ZIndex = 5
	Keywords_.Font = Enum.Font.Code
	Keywords_.Text = ""
	Keywords_.TextColor3 = Color3.fromRGB(248, 109, 124)
	Keywords_.TextSize = 15.000
	Keywords_.TextXAlignment = Enum.TextXAlignment.Left
	Keywords_.TextYAlignment = Enum.TextYAlignment.Top

	Numbers_.Name = "Numbers_"
	Numbers_.Parent = Source
	Numbers_.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
	Numbers_.BackgroundTransparency = 1.000
	Numbers_.Size = UDim2.new(1, 0, 1, 0)
	Numbers_.ZIndex = 4
	Numbers_.Font = Enum.Font.Code
	Numbers_.Text = ""
	Numbers_.TextColor3 = Color3.fromRGB(255, 198, 0)
	Numbers_.TextSize = 15.000
	Numbers_.TextXAlignment = Enum.TextXAlignment.Left
	Numbers_.TextYAlignment = Enum.TextYAlignment.Top

	RemoteHighlight_.Name = "RemoteHighlight_"
	RemoteHighlight_.Parent = Source
	RemoteHighlight_.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
	RemoteHighlight_.BackgroundTransparency = 1.000
	RemoteHighlight_.Size = UDim2.new(1, 0, 1, 0)
	RemoteHighlight_.ZIndex = 5
	RemoteHighlight_.Font = Enum.Font.Code
	RemoteHighlight_.Text = ""
	RemoteHighlight_.TextColor3 = Color3.fromRGB(0, 144, 255)
	RemoteHighlight_.TextSize = 15.000
	RemoteHighlight_.TextXAlignment = Enum.TextXAlignment.Left
	RemoteHighlight_.TextYAlignment = Enum.TextYAlignment.Top

	Strings_.Name = "Strings_"
	Strings_.Parent = Source
	Strings_.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
	Strings_.BackgroundTransparency = 1.000
	Strings_.Size = UDim2.new(1, 0, 1, 0)
	Strings_.ZIndex = 5
	Strings_.Font = Enum.Font.Code
	Strings_.Text = ""
	Strings_.TextColor3 = Color3.fromRGB(173, 241, 149)
	Strings_.TextSize = 15.000
	Strings_.TextXAlignment = Enum.TextXAlignment.Left
	Strings_.TextYAlignment = Enum.TextYAlignment.Top

	Tokens_.Name = "Tokens_"
	Tokens_.Parent = Source
	Tokens_.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
	Tokens_.BackgroundTransparency = 1.000
	Tokens_.Size = UDim2.new(1, 0, 1, 0)
	Tokens_.ZIndex = 5
	Tokens_.Font = Enum.Font.Code
	Tokens_.Text = ""
	Tokens_.TextColor3 = Color3.fromRGB(255, 255, 255)
	Tokens_.TextSize = 15.000
	Tokens_.TextXAlignment = Enum.TextXAlignment.Left
	Tokens_.TextYAlignment = Enum.TextYAlignment.Top

	Lines.Name = "Lines"
	Lines.Parent = EditorFrame
	Lines.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
	Lines.BackgroundTransparency = 1.000
	Lines.Position = UDim2.new(0, 0, 0.000158645402, 0)
	Lines.Size = UDim2.new(-0.0236694496, 30, 0.999841273, 0)
	Lines.ZIndex = 4
	Lines.Font = Enum.Font.Code
	Lines.Text = "1"
	Lines.TextColor3 = Color3.fromRGB(255, 255, 255)
	Lines.TextSize = 15.000
	Lines.TextYAlignment = Enum.TextYAlignment.Top

	Execute.Name = "Execute"
	Execute.Parent = NCE
	Execute.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
	Execute.BackgroundTransparency = 1.000
	Execute.BorderSizePixel = 0
	Execute.Position = UDim2.new(0.0123203294, 0, 0.904255331, 0)
	Execute.Size = UDim2.new(0, 46, 0, 21)
	Execute.ZIndex = 2
	Execute.Font = Enum.Font.SourceSans
	Execute.Text = "Execute"
	Execute.TextColor3 = Color3.fromRGB(255, 255, 255)
	Execute.TextSize = 14.000
	Execute.MouseButton1Click:Connect(function()
		if string.sub(Source.Text,1,1) == "." then
			local e = string.lower(Source.Text)
			if e == ".jojo" then
				Run('game:GetService("SoundService"):ClearAllChildren()')()
				cmd('jojo')
			elseif e == ".knife" then
					cmd('knife')
			elseif e == ".sd" or e == ".shutdown" then
				cmd('ss')
			elseif e == ".ds" or e == ".nuke" then
				cmd('ds')
			elseif e == ".spook" then
				Run([[
				local xd = Instance.new("Sound", game:GetService("SoundService"))
				xd.SoundId = "rbxassetid://1008645583"
				xd.Volume = 10
				xd.Looped = true
				xd:Play()
				local lights = game:GetService("Lighting")
				lights:ClearAllChildren()
				lights.TimeOfDay = "00:00:00"
				lights.FogEnd = 0
				lights.FogColor = Color3.new(0, 0, 0)
				lights.Brightness = 0
				lights.ExposureCompensation = -3
				]])()
			elseif e == ".lock" then
				Run('game:GetService("Players").PlayerAdded:Connect(function(idiot) idiot:Kick("Server Locked") end)')()
			end
		else
			Run(Source.Text)()
		end
	end)

	TextButton_Roundify_4px.Name = "TextButton_Roundify_4px"
	TextButton_Roundify_4px.Parent = Execute
	TextButton_Roundify_4px.Active = true
	TextButton_Roundify_4px.AnchorPoint = Vector2.new(0.5, 0.5)
	TextButton_Roundify_4px.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
	TextButton_Roundify_4px.BackgroundTransparency = 1.000
	TextButton_Roundify_4px.Position = UDim2.new(0.5, 0, 0.5, 0)
	TextButton_Roundify_4px.Selectable = true
	TextButton_Roundify_4px.Size = UDim2.new(1, 0, 1, 0)
	TextButton_Roundify_4px.Image = "rbxassetid://3570695787"
	TextButton_Roundify_4px.ImageColor3 = Color3.fromRGB(34, 34, 34)
	TextButton_Roundify_4px.ScaleType = Enum.ScaleType.Slice
	TextButton_Roundify_4px.SliceCenter = Rect.new(100, 100, 100, 100)
	TextButton_Roundify_4px.SliceScale = 0.040

	Clear.Name = "Clear"
	Clear.Parent = NCE
	Clear.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
	Clear.BackgroundTransparency = 1.000
	Clear.BorderSizePixel = 0
	Clear.Position = UDim2.new(0.1232033, 0, 0.904255331, 0)
	Clear.Size = UDim2.new(0, 46, 0, 21)
	Clear.ZIndex = 2
	Clear.Font = Enum.Font.SourceSans
	Clear.Text = "Clear"
	Clear.TextColor3 = Color3.fromRGB(255, 255, 255)
	Clear.TextSize = 14.000

	TextButton_Roundify_4px_2.Name = "TextButton_Roundify_4px"
	TextButton_Roundify_4px_2.Parent = Clear
	TextButton_Roundify_4px_2.Active = true
	TextButton_Roundify_4px_2.AnchorPoint = Vector2.new(0.5, 0.5)
	TextButton_Roundify_4px_2.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
	TextButton_Roundify_4px_2.BackgroundTransparency = 1.000
	TextButton_Roundify_4px_2.Position = UDim2.new(0.5, 0, 0.5, 0)
	TextButton_Roundify_4px_2.Selectable = true
	TextButton_Roundify_4px_2.Size = UDim2.new(1, 0, 1, 0)
	TextButton_Roundify_4px_2.Image = "rbxassetid://3570695787"
	TextButton_Roundify_4px_2.ImageColor3 = Color3.fromRGB(34, 34, 34)
	TextButton_Roundify_4px_2.ScaleType = Enum.ScaleType.Slice
	TextButton_Roundify_4px_2.SliceCenter = Rect.new(100, 100, 100, 100)
	TextButton_Roundify_4px_2.SliceScale = 0.040

	R6.Name = "R6"
	R6.Parent = NCE
	R6.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
	R6.BackgroundTransparency = 1.000
	R6.BorderSizePixel = 0
	R6.Position = UDim2.new(0.21765916, 0, 0.904255331, 0)
	R6.Size = UDim2.new(0, 46, 0, 21)
	R6.ZIndex = 2
	R6.Font = Enum.Font.SourceSans
	R6.Text = "R6"
	R6.TextColor3 = Color3.fromRGB(255, 255, 255)
	R6.TextSize = 14.000
	R6.MouseButton1Click:Connect(function()
		cmd('r6')
	end)
	
	TextButton_Roundify_4px_3.Name = "TextButton_Roundify_4px"
	TextButton_Roundify_4px_3.Parent = R6
	TextButton_Roundify_4px_3.Active = true
	TextButton_Roundify_4px_3.AnchorPoint = Vector2.new(0.5, 0.5)
	TextButton_Roundify_4px_3.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
	TextButton_Roundify_4px_3.BackgroundTransparency = 1.000
	TextButton_Roundify_4px_3.Position = UDim2.new(0.5, 0, 0.5, 0)
	TextButton_Roundify_4px_3.Selectable = true
	TextButton_Roundify_4px_3.Size = UDim2.new(1, 0, 1, 0)
	TextButton_Roundify_4px_3.Image = "rbxassetid://3570695787"
	TextButton_Roundify_4px_3.ImageColor3 = Color3.fromRGB(34, 34, 34)
	TextButton_Roundify_4px_3.ScaleType = Enum.ScaleType.Slice
	TextButton_Roundify_4px_3.SliceCenter = Rect.new(100, 100, 100, 100)
	TextButton_Roundify_4px_3.SliceScale = 0.040

	Respawn.Name = "Respawn"
	Respawn.Parent = NCE
	Respawn.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
	Respawn.BackgroundTransparency = 1.000
	Respawn.BorderSizePixel = 0
	Respawn.Position = UDim2.new(0.328542113, 0, 0.904255331, 0)
	Respawn.Size = UDim2.new(0, 46, 0, 21)
	Respawn.ZIndex = 2
	Respawn.Font = Enum.Font.SourceSans
	Respawn.Text = "Gun"
	Respawn.TextColor3 = Color3.fromRGB(255, 255, 255)
	Respawn.TextSize = 14.000
	Respawn.MouseButton1Click:Connect(function()
		cmd('Gun')
	end)

	TextButton_Roundify_4px_4.Name = "TextButton_Roundify_4px"
	TextButton_Roundify_4px_4.Parent = Respawn
	TextButton_Roundify_4px_4.Active = true
	TextButton_Roundify_4px_4.AnchorPoint = Vector2.new(0.5, 0.5)
	TextButton_Roundify_4px_4.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
	TextButton_Roundify_4px_4.BackgroundTransparency = 1.000
	TextButton_Roundify_4px_4.Position = UDim2.new(0.5, 0, 0.5, 0)
	TextButton_Roundify_4px_4.Selectable = true
	TextButton_Roundify_4px_4.Size = UDim2.new(1, 0, 1, 0)
	TextButton_Roundify_4px_4.Image = "rbxassetid://3570695787"
	TextButton_Roundify_4px_4.ImageColor3 = Color3.fromRGB(34, 34, 34)
	TextButton_Roundify_4px_4.ScaleType = Enum.ScaleType.Slice
	TextButton_Roundify_4px_4.SliceCenter = Rect.new(100, 100, 100, 100)
	TextButton_Roundify_4px_4.SliceScale = 0.040

	Antiban.Name = "Antiban"
	Antiban.Parent = NCE
	Antiban.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
	Antiban.BackgroundTransparency = 1.000
	Antiban.BorderSizePixel = 0
	Antiban.Position = UDim2.new(0.451745421, 0, 0.904255331, 0)
	Antiban.Size = UDim2.new(0, 46, 0, 21)
	Antiban.ZIndex = 2
	Antiban.Font = Enum.Font.SourceSans
	Antiban.Text = "Antiban"
	Antiban.TextColor3 = Color3.fromRGB(255, 255, 255)
	Antiban.TextSize = 14.000
	Antiban.MouseButton1Click:Connect(function()
		Run('require(3986243232).load("Please try again later")')()
		print("Anti Ban Enabled")
	end)

	TextButton_Roundify_4px_5.Name = "TextButton_Roundify_4px"
	TextButton_Roundify_4px_5.Parent = Antiban
	TextButton_Roundify_4px_5.Active = true
	TextButton_Roundify_4px_5.AnchorPoint = Vector2.new(0.5, 0.5)
	TextButton_Roundify_4px_5.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
	TextButton_Roundify_4px_5.BackgroundTransparency = 1.000
	TextButton_Roundify_4px_5.Position = UDim2.new(0.5, 0, 0.5, 0)
	TextButton_Roundify_4px_5.Selectable = true
	TextButton_Roundify_4px_5.Size = UDim2.new(1, 0, 1, 0)
	TextButton_Roundify_4px_5.Image = "rbxassetid://3570695787"
	TextButton_Roundify_4px_5.ImageColor3 = Color3.fromRGB(34, 34, 34)
	TextButton_Roundify_4px_5.ScaleType = Enum.ScaleType.Slice
	TextButton_Roundify_4px_5.SliceCenter = Rect.new(100, 100, 100, 100)
	TextButton_Roundify_4px_5.SliceScale = 0.040

	Status.Name = "Status"
	Status.Parent = NCE
	Status.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
	Status.BackgroundTransparency = 10.000
	Status.Position = UDim2.new(0.784394324, 0, 0.90780139, 0)
	Status.Size = UDim2.new(0, 61, 0, 19)
	Status.Font = Enum.Font.SourceSans
	Status.Text = "Status:"
	Status.TextColor3 = Color3.fromRGB(255, 255, 255)
	Status.TextSize = 14.000

	Injected.Name = "Injected"
	Injected.Parent = NCE
	Injected.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
	Injected.BackgroundTransparency = 10.000
	Injected.Position = UDim2.new(0.872689962, 0, 0.90780139, 0)
	Injected.Size = UDim2.new(0, 61, 0, 19)
	Injected.Font = Enum.Font.SourceSans
	Injected.Text = "Injected!"
	Injected.TextColor3 = Color3.fromRGB(0, 255, 0)
	Injected.TextSize = 14.000



	local fake_module_scripts = {}

	do
		local script = Instance.new('ModuleScript', R6)
		script.Name = "effectR"
		local function module_script()
			function CircleClick(d,b,a)coroutine.resume(coroutine.create(function()d.ClipsDescendants=true local c=script:WaitForChild("Circle"):Clone()c.Parent=d local b=b-c.AbsolutePosition.X local a=a-c.AbsolutePosition.Y c.Position=UDim2.new(0,b,0,a)local a=0 if d.AbsoluteSize.X>d.AbsoluteSize.Y then a=d.AbsoluteSize.X*1.5 elseif d.AbsoluteSize.X<d.AbsoluteSize.Y then a=d.AbsoluteSize.Y*1.5 elseif d.AbsoluteSize.X==d.AbsoluteSize.Y then a=d.AbsoluteSize.X*1.5 end local b=0.5 c:TweenSizeAndPosition(UDim2.new(0,a,0,a),UDim2.new(0.5,-a/2,0.5,-a/2),"Out","Quad",b,false,nil)for a=1,10 do c.ImageTransparency=c.ImageTransparency+0.01 wait(b/10)end c:Destroy()end))end return CircleClick
		end
		fake_module_scripts[script] = module_script
	end




	local function ZVXMU_fake_script()
		local script = Instance.new('LocalScript', Close)
		local req = require
		local require = function(obj)
			local fake = fake_module_scripts[obj]
			if fake then
				return fake()
			end
			return req(obj)
		end

		script.Parent.MouseEnter:Connect(function()
			game:GetService("TweenService"):Create(script.Parent, TweenInfo.new(0.25), {['TextColor3'] = Color3.fromRGB(100,100,100)}):Play()
		end)

		script.Parent.MouseLeave:Connect(function()
			game:GetService("TweenService"):Create(script.Parent, TweenInfo.new(0.25), {['TextColor3'] = Color3.fromRGB(255, 255, 255)}):Play()
		end)
	end
	coroutine.wrap(ZVXMU_fake_script)()
	local function MWBLSLD_fake_script()
		local script = Instance.new('LocalScript', Close)
		local req = require
		local require = function(obj)
			local fake = fake_module_scripts[obj]
			if fake then
				return fake()
			end
			return req(obj)
		end

		local opened = false

		script.Parent.MouseButton1Click:Connect(function()
			if opened == false then
				script.Parent.Parent.Parent.EditorFrame.Visible = false
				script.Parent.Parent.Parent.Execute.Visible = false
				script.Parent.Parent.Parent.R6.Visible = false
				script.Parent.Parent.Parent.Respawn.Visible = false
				script.Parent.Parent.Parent.Clear.Visible = false
				script.Parent.Parent.Parent.Status.Visible = false
				script.Parent.Parent.Parent.Injected.Visible = false
				script.Parent.Parent.Parent.Antiban.Visible = false
				script.Parent.Parent.Parent.Parent.NCE:TweenSize(UDim2.new(0, 487,0, 27, "Out", "Bounce", 1))
				opened = true
			else
				script.Parent.Parent.Parent.Parent.NCE:TweenSize(UDim2.new(0, 487,0, 282, "Out", "Bounce", 1))
				script.Parent.Parent.Parent.EditorFrame.Visible = true
				script.Parent.Parent.Parent.Execute.Visible = true
				script.Parent.Parent.Parent.R6.Visible = true
				script.Parent.Parent.Parent.Respawn.Visible = true
				script.Parent.Parent.Parent.Clear.Visible = true
				script.Parent.Parent.Parent.Status.Visible = true
				script.Parent.Parent.Parent.Injected.Visible = true
				script.Parent.Parent.Parent.Antiban.Visible = true
				opened = false
			end
		end)
	end
	coroutine.wrap(MWBLSLD_fake_script)()
	local function NUGLAKU_fake_script() 
		local script = Instance.new('LocalScript', Execute)
		local req = require
		local require = function(obj)
			local fake = fake_module_scripts[obj]
			if fake then
				return fake()
			end
			return req(obj)
		end

		script.Parent.MouseEnter:Connect(function()
			game:GetService("TweenService"):Create(script.Parent, TweenInfo.new(0.25), {['TextColor3'] = Color3.fromRGB(100,100,100)}):Play()
		end)

		script.Parent.MouseLeave:Connect(function()
			game:GetService("TweenService"):Create(script.Parent, TweenInfo.new(0.25), {['TextColor3'] = Color3.fromRGB(255, 255, 255)}):Play()
		end)
	end
	coroutine.wrap(NUGLAKU_fake_script)()
	local function MQICOGM_fake_script()
		local script = Instance.new('LocalScript', NCE)
		local req = require
		local require = function(obj)
			local fake = fake_module_scripts[obj]
			if fake then
				return fake()
			end
			return req(obj)
		end

		local lua_keywords = {"and", "break", "do", "else", "elseif", "end", "false", "for", "function", "goto", "if", "in", "local", "nil", "not", "or", "repeat", "return", "then", "true", "until", "while"}
		local global_env = {"getrawmetatable", "game", "workspace", "script", "math", "string", "table", "print", "wait", "BrickColor", "Color3", "next", "pairs", "ipairs", "select", "unpack", "Instance", "Vector2", "Vector3", "CFrame", "Ray", "UDim2", "Enum", "assert", "error", "warn", "tick", "loadstring", "_G", "shared", "getfenv", "setfenv", "newproxy", "setmetatable", "getmetatable", "os", "debug", "pcall", "ypcall", "xpcall", "rawequal", "rawset", "rawget", "tonumber", "tostring", "type", "typeof", "_VERSION", "coroutine", "delay", "require", "spawn", "LoadLibrary", "settings", "stats", "time", "UserSettings", "version", "Axes", "ColorSequence", "Faces", "ColorSequenceKeypoint", "NumberRange", "NumberSequence", "NumberSequenceKeypoint", "gcinfo", "elapsedTime", "collectgarbage", "PhysicalProperties", "Rect", "Region3", "Region3int16", "UDim", "Vector2int16", "Vector3int16", "jojo", "knife", "sd", "shutdown", "ds", "nuke", "spook", "lock"}

		local Source = script.Parent.EditorFrame.Source
		local Lines = Source.Parent.Lines

		local Highlight = function(string, keywords)
			local K = {}
			local S = string
			local Token =
				{
					["="] = true,
					["."] = true,
					[","] = true,
					["("] = true,
					[")"] = true,
					["["] = true,
					["]"] = true,
					["{"] = true,
					["}"] = true,
					[":"] = true,
					["*"] = true,
					["/"] = true,
					["+"] = true,
					["-"] = true,
					["%"] = true,
					[";"] = true,
					["~"] = true
				}
			for i, v in pairs(keywords) do
				K[v] = true
			end
			S = S:gsub(".", function(c)
				if Token[c] ~= nil then
					return "\32"
				else
					return c
				end
			end)
			S = S:gsub("%S+", function(c)
				if K[c] ~= nil then
					return c
				else
					return (" "):rep(#c)
				end
			end)

			return S
		end

		local hTokens = function(string)
			local Token =
				{
					["="] = true,
					["."] = true,
					[","] = true,
					["("] = true,
					[")"] = true,
					["["] = true,
					["]"] = true,
					["{"] = true,
					["}"] = true,
					[":"] = true,
					["*"] = true,
					["/"] = true,
					["+"] = true,
					["-"] = true,
					["%"] = true,
					[";"] = true,
					["~"] = true
				}
			local A = ""
			string:gsub(".", function(c)
				if Token[c] ~= nil then
					A = A .. c
				elseif c == "\n" then
					A = A .. "\n"
				elseif c == "\t" then
					A = A .. "\t"
				else
					A = A .. "\32"
				end
			end)

			return A
		end


		local strings = function(string)
			local highlight = ""
			local quote = false
			string:gsub(".", function(c)
				if quote == false and c == "\"" then
					quote = true
				elseif quote == true and c == "\"" then
					quote = false
				end
				if quote == false and c == "\"" then
					highlight = highlight .. "\""
				elseif c == "\n" then
					highlight = highlight .. "\n"
				elseif c == "\t" then
					highlight = highlight .. "\t"
				elseif quote == true then
					highlight = highlight .. c
				elseif quote == false then
					highlight = highlight .. "\32"
				end
			end)

			return highlight
		end

		local comments = function(string)
			local ret = ""
			string:gsub("[^\r\n]+", function(c)
				local comm = false
				local i = 0
				c:gsub(".", function(n)
					i = i + 1
					if c:sub(i, i + 1) == "--" then
						comm = true
					end
					if comm == true then
						ret = ret .. n
					else
						ret = ret .. "\32"
					end
				end)
				ret = ret
			end)

			return ret
		end

		local numbers = function(string)
			local A = ""
			string:gsub(".", function(c)
				if tonumber(c) ~= nil then
					A = A .. c
				elseif c == "\n" then
					A = A .. "\n"
				elseif c == "\t" then
					A = A .. "\t"
				else
					A = A .. "\32"
				end
			end)

			return A
		end

		local highlight_source = function(type)
			if type == "Text" then
				Source.Text = Source.Text:gsub("\13", "")
				Source.Text = Source.Text:gsub("\t", "      ")
				local s = Source.Text
				Source.Keywords_.Text = Highlight(s, lua_keywords)
				Source.Globals_.Text = Highlight(s, global_env)
				Source.RemoteHighlight_.Text = Highlight(s, {"FireServer", "fireServer", "InvokeServer", "invokeServer"})
				Source.Tokens_.Text = hTokens(s)
				Source.Numbers_.Text = numbers(s)
				Source.Strings_.Text = strings(s)
				local lin = 1
				s:gsub("\n", function()
					lin = lin + 1
				end)
				Lines.Text = ""
				for i = 1, lin do
					Lines.Text = Lines.Text .. i .. "\n"
				end
			end
		end

		highlight_source("Text")

		Source.Changed:Connect(highlight_source)
	end
	coroutine.wrap(MQICOGM_fake_script)()
	local function WNVD_fake_script() 
		local script = Instance.new('LocalScript', NCE)
		local req = require
		local require = function(obj)
			local fake = fake_module_scripts[obj]
			if fake then
				return fake()
			end
			return req(obj)
		end

		local a=game:GetService("UserInputService")function drag(b)dragToggle=nil dragSpeed=0.23 dragInput=nil dragStart=nil dragPos=nil function updateInput(a)Delta=a.Position-dragStart Position=UDim2.new(startPos.X.Scale,startPos.X.Offset+Delta.X,startPos.Y.Scale,startPos.Y.Offset+Delta.Y)game:GetService("TweenService"):Create(b,TweenInfo.new(0.25),{Position=Position}):Play()end b.InputBegan:Connect(function(c)if(c.UserInputType==Enum.UserInputType.MouseButton1 or c.UserInputType==Enum.UserInputType.Touch)and a:GetFocusedTextBox()==nil then dragToggle=true dragStart=c.Position startPos=b.Position c.Changed:Connect(function()if c.UserInputState==Enum.UserInputState.End then dragToggle=false end end)end end)b.InputChanged:Connect(function(a)if a.UserInputType==Enum.UserInputType.MouseMovement or a.UserInputType==Enum.UserInputType.Touch then dragInput=a end end)game:GetService("UserInputService").InputChanged:Connect(function(a)if a==dragInput and dragToggle then updateInput(a)end end)end drag(script.Parent)
	end
	coroutine.wrap(WNVD_fake_script)()
	local function GLSZS_fake_script()
		local script = Instance.new('LocalScript', Clear)
		local req = require
		local require = function(obj)
			local fake = fake_module_scripts[obj]
			if fake then
				return fake()
			end
			return req(obj)
		end

		script.Parent.MouseEnter:Connect(function()
			game:GetService("TweenService"):Create(script.Parent, TweenInfo.new(0.25), {['TextColor3'] = Color3.fromRGB(100,100,100)}):Play()
		end)

		script.Parent.MouseLeave:Connect(function()
			game:GetService("TweenService"):Create(script.Parent, TweenInfo.new(0.25), {['TextColor3'] = Color3.fromRGB(255, 255, 255)}):Play()
		end)
	end
	coroutine.wrap(GLSZS_fake_script)()
	local function IUFS_fake_script()
		local script = Instance.new('LocalScript', R6)
		local req = require
		local require = function(obj)
			local fake = fake_module_scripts[obj]
			if fake then
				return fake()
			end
			return req(obj)
		end

		script.Parent.MouseEnter:Connect(function()
			game:GetService("TweenService"):Create(script.Parent, TweenInfo.new(0.25), {['TextColor3'] = Color3.fromRGB(100,100,100)}):Play()
		end)

		script.Parent.MouseLeave:Connect(function()
			game:GetService("TweenService"):Create(script.Parent, TweenInfo.new(0.25), {['TextColor3'] = Color3.fromRGB(255, 255, 255)}):Play()
		end)
	end
	coroutine.wrap(IUFS_fake_script)()

	local function GOZFXLU_fake_script()
		local script = Instance.new('LocalScript', Respawn)
		local req = require
		local require = function(obj)
			local fake = fake_module_scripts[obj]
			if fake then
				return fake()
			end
			return req(obj)
		end

		script.Parent.MouseEnter:Connect(function()
			game:GetService("TweenService"):Create(script.Parent, TweenInfo.new(0.25), {['TextColor3'] = Color3.fromRGB(100,100,100)}):Play()
		end)

		script.Parent.MouseLeave:Connect(function()
			game:GetService("TweenService"):Create(script.Parent, TweenInfo.new(0.25), {['TextColor3'] = Color3.fromRGB(255, 255, 255)}):Play()
		end)
	end
	coroutine.wrap(GOZFXLU_fake_script)()
	local function RJYXLA_fake_script() 
		local script = Instance.new('LocalScript', Antiban)
		local req = require
		local require = function(obj)
			local fake = fake_module_scripts[obj]
			if fake then
				return fake()
			end
			return req(obj)
		end

		script.Parent.MouseEnter:Connect(function()
			game:GetService("TweenService"):Create(script.Parent, TweenInfo.new(0.25), {['TextColor3'] = Color3.fromRGB(100,100,100)}):Play()
		end)

		script.Parent.MouseLeave:Connect(function()
			game:GetService("TweenService"):Create(script.Parent, TweenInfo.new(0.25), {['TextColor3'] = Color3.fromRGB(255, 255, 255)}):Play()
		end)
	end
	coroutine.wrap(RJYXLA_fake_script)()
	local function JOXF_fake_script()
		local script = Instance.new('LocalScript', NCE)
		local req = require
		local require = function(obj)
			local fake = fake_module_scripts[obj]
			if fake then
				return fake()
			end
			return req(obj)
		end


		local Source = script.Parent.EditorFrame.Source
		local Clear = script.Parent.Clear 


		Clear.MouseButton1Click:Connect(function()
			Source.Text = ""
		end)
	end
	coroutine.wrap(JOXF_fake_script)()
else
    print("Nap client has either been removed or disabled")
end