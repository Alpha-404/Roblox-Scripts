local Plrs = {}

for i,v in pairs(game:GetService("Players"):GetPlayers()) do
	if gethiddenproperty(v, "SimulationRadius") >= 5000 then
		table.insert(Plrs, v.Name)
	end
end

if #Plrs <= 0 then
	print("Network check ran: No players have been found using networkownership.")
elseif #Plrs == 1 and Plrs[1] ~= game:GetService("Players").LocalPlayer.Name then
	print("Network check ran, the player using network: " .. Plrs[1])
elseif #Plrs == 1 and Plrs[1] == game:GetService("Players").LocalPlayer.Name then
    print("You are the only network owner")
elseif #Plrs > 1 then
	print("Network Check Ran, People Using Net : ")
	for i, v in pairs(Plrs) do
		print(v)
	end
end