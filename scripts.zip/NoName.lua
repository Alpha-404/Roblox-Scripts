	for i,v in pairs(game:GetService("Players").LocalPlayer.Character:GetDescendants())do
		if v:IsA("BillboardGui") or v:IsA("SurfaceGui") then
			v:Destroy()
		end
	end