getgenv().Config = {
    InfHealth = true,
    InfStamina = true,
    InfBodyBags = true,
    InfCableTies = true,
    InfAmmo = true,
    AutoTpBagsToVan = true
}

if getgenv().Config.InfHealth == true then
	game:GetService("RunService").Stepped:Connect(function()
		workspace.Criminals[game:GetService("Players").LocalPlayer.Name].Health.Value = 255
	end)
end

if getgenv().Config.InfStamina == true then
	game:GetService("RunService").Stepped:Connect(function()
		workspace.Criminals[game:GetService("Players").LocalPlayer.Name].Stamina.Value = 120
	end)
end

if getgenv().Config.InfBodyBags == true then
	game:GetService("RunService").Stepped:Connect(function()
		workspace.Criminals[game:GetService("Players").LocalPlayer.Name].BodyBags.Value = 3
	end)
end

if getgenv().Config.InfCableTies == true then
	game:GetService("RunService").Stepped:Connect(function()
		workspace.Criminals[game:GetService("Players").LocalPlayer.Name].CableTies.Value = 255
	end)
end

if getgenv().Config.InfAmmo == true then
	game:GetService("RunService").Stepped:Connect(function()
		workspace.Criminals[game:GetService("Players").LocalPlayer.Name].PrimaryAmmo.Value = 100
		workspace.Criminals[game:GetService("Players").LocalPlayer.Name].SecondaryAmmo.Value = 100
	end)
end

if getgenv().Config.AutoTpBagsToVan == true then
	game:GetService("RunService").Stepped:Connect(function()
	    wait(1)
	    for i,v in pairs(workspace.Bags:GetDescendants()) do
	        if v.Name == "MoneyBag" then
		        v.CFrame = workspace.BagSecuredArea.FloorPart.CFrame + Vector3.new(0,5,0)
	        end
        end
    end)
end

print("Loaded Script B)")