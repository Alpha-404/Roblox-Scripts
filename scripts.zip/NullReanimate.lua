--Keybinds
_G.UnReanimateKey = "q" --The keybind for unreanimating.
_G.ReanimateKey = "e" --The keybind for reanimating.
_G.R6ToggleKey = "r" --The keybind for toggling R15 to R6.
_G.GodmodeToggleKey = "t" --The keybind for toggling godmode.
--Options
_G.CharacterBug = false --Set to true if your uppertorso floats when you use godmode with R15.
_G.GodMode = false --Set to true if you want godmode.
_G.R6 = false --Set to true if you wanna enable R15 to R6 when your R15.
_G.FastLoading = false --Set to true if you want godmode to load faster. (Can make you respawn after you reanimate by a chance.)
_G.AutoReanimate = true --Set to true if you want to auto reanimate and disable keybinds after executing.

loadstring(game:HttpGet("https://paste.ee/r/5K7Kc/0"))()