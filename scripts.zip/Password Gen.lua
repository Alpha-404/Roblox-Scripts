function random()
    local length = math.random(10,20)
    local array = {}
    for i = 1, length do
        array[i] = string.char(math.random(32, 126))
    end
    return table.concat(array)
end
local p1 = random()
local p2 = random()
local p3 = random()
local p4 = random()
local p5 = random()
local p6 = random()
local p7 = random()
local p8 = random()
local p9 = random()
local p10 = random()

print("Generated Password : " .. p1 .. p2 .. p3 .. p4 .. p5 .. p6 .. p7 .. p8 .. p9 .. p10)
setclipboard(p1 .. p2 .. p3 .. p4 .. p5 .. p6 .. p7 .. p8 .. p9 .. p10)