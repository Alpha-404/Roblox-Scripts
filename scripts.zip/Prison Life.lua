game:GetService("Players").LocalPlayer.CharacterAdded:Connect(function()
    wait(0.5)
    local userdata_1 = workspace["Prison_ITEMS"].giver["Remington 870"].ITEMPICKUP;
    local Target = workspace.Remote.ItemHandler;
    Target:InvokeServer(userdata_1);
    local userdata_1 = game:GetService("Workspace")["Prison_ITEMS"].giver["AK-47"].ITEMPICKUP;
    local Target = game:GetService("Workspace").Remote.ItemHandler;
    Target:InvokeServer(userdata_1);
    while game:GetService("Players").LocalPlayer.Character ~= nil do
        game:GetService("StarterGui"):SetCoreGuiEnabled(Enum.CoreGuiType.Backpack, true)
        if game:GetService("Players").LocalPlayer.Character.Humanoid.WalkSpeed == 5 then
            game:GetService("Players").LocalPlayer.Character.Humanoid.WalkSpeed = 50
            game:GetService("Players").LocalPlayer.Character.Humanoid.JumpPower = 100
        end
        if game:GetService("Players").LocalPlayer.Character.Humanoid.WalkSpeed ~= (5 or 50 or 16) then
            game:GetService("Players").LocalPlayer.Character.Humanoid.WalkSpeed = 26
        end
        wait()
    end
end)
local UserInputService = game:GetService("UserInputService")
local mouse = game:GetService("Players").LocalPlayer:GetMouse()
UserInputService.InputBegan:Connect(function(key)
	if key.keyCode == Enum.KeyCode.F then
	    if game:GetService('Players').LocalPlayer:GetMouse().Target == nil then 
	        return 
	    else 
	        if mouse.Target.Parent:FindFirstChild("Humanoid") then
	            local idiot = mouse.Target.Parent.Name 
	            for i = 1, 50 do
	            wait()
                local userdata_1 = game:GetService("Players")[idiot];
                local Target = game:GetService("ReplicatedStorage").meleeEvent;
                Target:FireServer(userdata_1);
                end
	        end
	    end
	end
end)
game:GetService("Players")["Terminated_Egg"].PlayerGui.Home.hud.AddedGui.tooltip.Visible = true
game:GetService("Players")["Terminated_Egg"].PlayerGui.Home.hud.AddedGui.tooltip.TextLabel.Text = "Prison Hax Loaded | By Birb#4125"
wait(3)
game:GetService("Players")["Terminated_Egg"].PlayerGui.Home.hud.AddedGui.tooltip.Visible = false