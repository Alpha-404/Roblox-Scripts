local old_pos = game:GetService("Players").LocalPlayer.Character.HumanoidRootPart.CFrame
game:GetService("Players").LocalPlayer.Character.HumanoidRootPart.CFrame = workspace.Maps.End.Light.CFrame
wait()
game:GetService("Players").LocalPlayer.Character.HumanoidRootPart.CFrame = old_pos