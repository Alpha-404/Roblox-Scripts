
local Players = game:GetService("Players")
wait(1)
if #Players:GetPlayers() <= 1 then
	Players.LocalPlayer:Kick("Teleporting...")
	wait()
	game:GetService('TeleportService'):Teleport(game.PlaceId, Players.LocalPlayer)
else
	game:GetService('TeleportService'):TeleportToPlaceInstance(game.PlaceId, game.JobId, Players.LocalPlayer)
end