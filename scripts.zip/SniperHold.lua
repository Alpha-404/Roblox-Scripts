if game:GetService("Players").LocalPlayer.Character:FindFirstChild("Meshes/SniperAccessory") then
	local plr = game:GetService("Players").LocalPlayer
	local char = plr.Character
	local Sniper = char["Meshes/SniperAccessory"]
	local SniperH = game:GetService("Players").LocalPlayer.Character["Meshes/SniperAccessory"].Handle
	SniperH:GetPropertyChangedSignal("LocalTransparencyModifier"):Connect(function()
		SniperH.LocalTransparencyModifier = SniperH.Transparency
	end)
	SniperH.LocalTransparencyModifier = SniperH.Transparency

	SniperH.AccessoryWeld:Destroy()

	if char:FindFirstChildOfClass('Humanoid').RigType == Enum.HumanoidRigType.R6 then
		local att0 = Instance.new("Attachment",SniperH)
		att0.CFrame = CFrame.new(1, -2.4000001, 0, -1.24828858e-08, 0.642787576, -0.766044438, 6.69697329e-08, -0.766044438, -0.642787576, -1, -5.9325636e-08, -3.34848664e-08)
		att0.Name = "SniperHook"

		local att1 = Instance.new("Attachment",char["Right Arm"])

		local ap = Instance.new("AlignPosition",SniperH)
		ap.Attachment0 = att0
		ap.Attachment1 = att1
		ap.RigidityEnabled = true 


		local ao = Instance.new("AlignOrientation",SniperH) 
		ao.Attachment0 = att0
		ao.Attachment1 = att1
		ao.RigidityEnabled = true

		local anim = game:GetService("Players").LocalPlayer.Character.Humanoid:LoadAnimation(game:GetService("Players").LocalPlayer.Character.Animate.toolnone.ToolNoneAnim)
		anim:Play()
		
		local e = game:GetService("Players").LocalPlayer:GetMouse().Button1Down:Connect(function()
		    if plr.Character == nil then return end
			game:GetService("TweenService"):Create(att0, TweenInfo.new(0.2), {['CFrame'] = CFrame.new(0.699999988, -2.4000001, 0, -1.8105851e-08, 0.707106829, -0.707106829, 6.18172393e-08, -0.707106829, -0.707106829, -1, -5.6514164e-08, -3.09086197e-08)}):Play()
			wait(0.2)
			game:GetService("TweenService"):Create(att0, TweenInfo.new(0.4), {['CFrame'] = CFrame.new(1, -2.4000001, 0, -1.24828858e-08, 0.642787576, -0.766044438, 6.69697329e-08, -0.766044438, -0.642787576, -1, -5.9325636e-08, -3.34848664e-08)}):Play()
		end)
		
		spawn(function()
			plr.CharacterAdded:Wait()
			e:Disconnect()
		end)
		
	elseif char:FindFirstChildOfClass('Humanoid').RigType == Enum.HumanoidRigType.R15 then
		local att0 = Instance.new("Attachment",SniperH)
		att0.Orientation = Vector3.new(40, -90, -180)
		att0.Position = Vector3.new(0, -1.2, 0)
		att0.Name = "SniperHook"

		local att1 = Instance.new("Attachment",char["RightHand"])

		local ap = Instance.new("AlignPosition",SniperH)
		ap.Attachment0 = att0
		ap.Attachment1 = att1
		ap.RigidityEnabled = true 


		local ao = Instance.new("AlignOrientation",SniperH) 
		ao.Attachment0 = att0
		ao.Attachment1 = att1
		ao.RigidityEnabled = true

		local anim = game:GetService("Players").LocalPlayer.Character.Humanoid:LoadAnimation(game:GetService("Players").LocalPlayer.Character.Animate.toolnone.ToolNoneAnim)
		anim:Play()
	end
end