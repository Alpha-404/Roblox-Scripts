game:GetService("Players").LocalPlayer.Character.Archivable = true 

local char = game:GetService("Players").LocalPlayer.Character
local hat = char["Shadow Antlers"]
hat.Handle.AccessoryWeld:Destroy()
hat.Handle.SpecialMesh:Destroy()
local bp = Instance.new("BodyPosition", hat.Handle)
bp.MaxForce = Vector3.new(math.huge*math.huge, math.huge*math.huge, math.huge*math.huge)
local bg = Instance.new("BodyGyro", hat.Handle)
bg.CFrame = CFrame.new(-6.19999981, 0.500003815, -4.19999981, 0.747806609, 0.368358403, 0.552356303, -0.530773163, 0.831478, 0.164085716, -0.398829758, -0.415880263, 0.817299485)
local bav = Instance.new("BodyAngularVelocity", hat.Handle)
bav.AngularVelocity = Vector3.new(0,2,0)
local f = game:GetService("RunService").Stepped:Connect(function()
    bp.Position = char["Head"].Position + Vector3.new(0,2.5,0)
end)
game:GetService("Players").LocalPlayer.CharacterAdded:Wait()
f:Disconnect()