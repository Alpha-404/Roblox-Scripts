local text = "https://raw.githubusercontent.com/EdgeIY/infiniteyield/master/source" --Text to turn into bytecode
local ct = ""
for i = 1,string.len(text) do
	ct = ct .. string.format("\\%s",string.byte(string.sub(text,i,i)))
	print(ct)
end
print('Converted To Bytecode')
setclipboard(ct)