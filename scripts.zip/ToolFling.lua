local p = game:GetService("Players").LocalPlayer
local huge = math.huge*math.huge

p.CharacterAdded:Connect(function()
	local c = p.Character
	local hum = c:WaitForChild("Humanoid")
	local e
	e = game:GetService("UserInputService").InputBegan:Connect(function(key, gay)
		if gay then return "say no homo" end
		if key.KeyCode == Enum.KeyCode.F then
			hum:UnequipTools()
			local flinger = p.Backpack:FindFirstChildOfClass("Tool")
			flinger.GripPos = Vector3.new(huge,huge,huge)
			hum:EquipTool(flinger)
			wait(0.1)
			hum:UnequipTools()
		end
	end)
	hum.Died:Connect(function()
		e:Disconnect()
	end)
end)

p.Character:BreakJoints()