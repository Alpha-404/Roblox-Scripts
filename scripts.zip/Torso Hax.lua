local hak = Instance.new("ScreenGui")
local Frame = Instance.new("Frame")
local TextLabel = Instance.new("TextLabel")
local Dinnerbone = Instance.new("TextButton")
local UICorner = Instance.new("UICorner")
local Dinnerbone_2 = Instance.new("TextButton")
local UICorner_2 = Instance.new("UICorner")
local Dinnerbone_3 = Instance.new("TextButton")
local UICorner_3 = Instance.new("UICorner")
local p = game:GetService("Players").LocalPlayer
local char = p.Character

hak.Name = "hak"
hak.Parent = game:GetService("CoreGui")
hak.ZIndexBehavior = Enum.ZIndexBehavior.Sibling

Frame.Parent = hak
Frame.BackgroundColor3 = Color3.fromRGB(33, 33, 33)
Frame.BorderSizePixel = 0
Frame.Position = UDim2.new(0.0110921487, 0, 0.825242639, 0)
Frame.Size = UDim2.new(0.141638219, 0, 0.162621364, 0)

TextLabel.Parent = Frame
TextLabel.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
TextLabel.BackgroundTransparency = 1.000
TextLabel.BorderSizePixel = 0
TextLabel.Size = UDim2.new(1, 0, 0.170212761, 0)
TextLabel.Font = Enum.Font.Cartoon
TextLabel.Text = "Torso Hax V2"
TextLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
TextLabel.TextSize = 14.000

Dinnerbone.Name = "Dinnerbone"
Dinnerbone.Parent = Frame
Dinnerbone.BackgroundColor3 = Color3.fromRGB(45, 45, 45)
Dinnerbone.BorderSizePixel = 0
Dinnerbone.Position = UDim2.new(0.0481927693, 0, 0.231343284, 0)
Dinnerbone.Size = UDim2.new(0.897590339, 0, 0.156716421, 0)
Dinnerbone.Font = Enum.Font.Cartoon
Dinnerbone.Text = "Dinnerbone"
Dinnerbone.TextColor3 = Color3.fromRGB(255, 255, 255)
Dinnerbone.TextSize = 14.000
Dinnerbone.MouseButton1Click:Connect(function()
	local NL

	NL = game:GetService("RunService").Stepped:Connect(function()
		if p.Character ~= nil then
			for _, child in pairs(char:GetDescendants()) do
				if child:IsA("BasePart") and child.CanCollide == true then
					child.CanCollide = false
				end
			end
		end
	end)

	spawn(function()
		p.CharacterAdded:Wait()
		NL:Disconnect()
	end)

	if char:FindFirstChildOfClass('Humanoid').RigType == Enum.HumanoidRigType.R15 then
		local att0 = Instance.new("Attachment",char["LowerTorso"])
		att0.Orientation = Vector3.new(-180, 180, 0)
		att0.Position = Vector3.new(0, 1, 0)
		att0.Name = "LT"

		local att1 = Instance.new("Attachment",char["HumanoidRootPart"])

		local ap = Instance.new("AlignPosition",char["HumanoidRootPart"])
		ap.Attachment0 = att0
		ap.Attachment1 = att1
		ap.RigidityEnabled = true 


		local ao = Instance.new("AlignOrientation",char["HumanoidRootPart"]) 
		ao.Attachment0 = att0
		ao.Attachment1 = att1
		ao.RigidityEnabled = true

		char["LowerTorso"].Root:Destroy()
	elseif char:FindFirstChildOfClass('Humanoid').RigType == Enum.HumanoidRigType.R6 then

		local att0 = Instance.new("Attachment",char["Torso"])
		att0.Orientation = Vector3.new(180, 180, 0)
		att0.Position = Vector3.new(0, 0, 0)
		att0.Name = "TORSO"

		local att1 = Instance.new("Attachment",char["HumanoidRootPart"])

		local ap = Instance.new("AlignPosition",char["HumanoidRootPart"])
		ap.Attachment0 = att0
		ap.Attachment1 = att1
		ap.RigidityEnabled = true 


		local ao = Instance.new("AlignOrientation",char["HumanoidRootPart"]) 
		ao.Attachment0 = att0
		ao.Attachment1 = att1
		ao.RigidityEnabled = true

		char["HumanoidRootPart"].RootJoint:Destroy()
	else
		print("wtf")
	end
end)

UICorner.Parent = Dinnerbone

Dinnerbone_2.Name = "Dinnerbone"
Dinnerbone_2.Parent = Frame
Dinnerbone_2.BackgroundColor3 = Color3.fromRGB(45, 45, 45)
Dinnerbone_2.BorderSizePixel = 0
Dinnerbone_2.Position = UDim2.new(0.0481927693, 0, 0.477611959, 0)
Dinnerbone_2.Size = UDim2.new(0.897590339, 0, 0.156716421, 0)
Dinnerbone_2.Font = Enum.Font.Cartoon
Dinnerbone_2.Text = "Sleeping"
Dinnerbone_2.TextColor3 = Color3.fromRGB(255, 255, 255)
Dinnerbone_2.TextSize = 14.000
Dinnerbone_2.MouseButton1Click:Connect(function()
	if p.Character:FindFirstChildOfClass('Humanoid').RigType == Enum.HumanoidRigType.R6 then
		local char = p.Character
		local NL

		NL = game:GetService("RunService").Stepped:Connect(function()
			if p.Character ~= nil then
				for _, child in pairs(char:GetDescendants()) do
					if child:IsA("BasePart") and child.CanCollide == true then
						child.CanCollide = false
					end
				end
			end
		end)

		spawn(function()
			p.CharacterAdded:Wait()
			NL:Disconnect()
		end)

		local att0 = Instance.new("Attachment",char["Torso"])
		att0.Orientation = Vector3.new(90,0,0)
		att0.Position = Vector3.new(0,0,2.5)
		att0.Name = "TORSO"

		local att1 = Instance.new("Attachment",char["HumanoidRootPart"])

		local ap = Instance.new("AlignPosition",char["HumanoidRootPart"])
		ap.Attachment0 = att0
		ap.Attachment1 = att1
		ap.RigidityEnabled = true 

		local ao = Instance.new("AlignOrientation",char["HumanoidRootPart"]) 
		ao.Attachment0 = att0
		ao.Attachment1 = att1
		ao.RigidityEnabled = true

		char["HumanoidRootPart"].RootJoint:Destroy()
	else
		game:GetService("StarterGui"):SetCore("SendNotification",{Title="Torso Hax",Text='R6 Only',Duration=5})
	end
end)

UICorner_2.Parent = Dinnerbone_2

Dinnerbone_3.Name = "Dinnerbone"
Dinnerbone_3.Parent = Frame
Dinnerbone_3.BackgroundColor3 = Color3.fromRGB(45, 45, 45)
Dinnerbone_3.BorderSizePixel = 0
Dinnerbone_3.Position = UDim2.new(0.0481927693, 0, 0.716417909, 0)
Dinnerbone_3.Size = UDim2.new(0.897590339, 0, 0.156716421, 0)
Dinnerbone_3.Font = Enum.Font.Cartoon
Dinnerbone_3.Text = "Invisible"
Dinnerbone_3.TextColor3 = Color3.fromRGB(255, 255, 255)
Dinnerbone_3.TextSize = 14.000
Dinnerbone_3.MouseButton1Click:Connect(function()
	if p.Character:FindFirstChildOfClass('Humanoid').RigType == Enum.HumanoidRigType.R6 then
		local att0 = Instance.new("Attachment",char["Torso"])
		att0.Orientation = Vector3.new(90,0,0)
		att0.Position = Vector3.new(0,0,2.5)
		att0.Name = "TORSO"

		local att1 = Instance.new("Attachment",char["HumanoidRootPart"])

		local ap = Instance.new("AlignPosition",char["HumanoidRootPart"])
		ap.Attachment0 = att0
		ap.Attachment1 = att1
		ap.RigidityEnabled = true 

		local ao = Instance.new("AlignOrientation",char["HumanoidRootPart"]) 
		ao.Attachment0 = att0
		ao.Attachment1 = att1
		ao.RigidityEnabled = true
		char["HumanoidRootPart"].RootJoint:Destroy()
		p.Character.Torso.TORSO.Position = Vector3.new(0, 50, 0)
	elseif p.Character:FindFirstChildOfClass('Humanoid').RigType == Enum.HumanoidRigType.R15 then
		local att0 = Instance.new("Attachment",char["LowerTorso"])
		att0.Orientation = Vector3.new(-180, 180, 0)
		att0.Position = Vector3.new(0, 1, 0)
		att0.Name = "LT"

		local att1 = Instance.new("Attachment",char["HumanoidRootPart"])

		local ap = Instance.new("AlignPosition",char["HumanoidRootPart"])
		ap.Attachment0 = att0
		ap.Attachment1 = att1
		ap.RigidityEnabled = true 


		local ao = Instance.new("AlignOrientation",char["HumanoidRootPart"]) 
		ao.Attachment0 = att0
		ao.Attachment1 = att1
		ao.RigidityEnabled = true

		char["LowerTorso"].Root:Destroy()

		p.Character.LowerTorso.LT.Position = Vector3.new(0, 50, 0)
	end
end)

UICorner_3.Parent = Dinnerbone_3