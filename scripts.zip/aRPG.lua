if game:GetService("Players").LocalPlayer.Character:FindFirstChild("WeaponAccessory") then
	local plr = game:GetService("Players").LocalPlayer
	local char = plr.Character
	local Sniper = char["WeaponAccessory"]
	local SniperH = game:GetService("Players").LocalPlayer.Character["WeaponAccessory"].Handle
	SniperH:GetPropertyChangedSignal("LocalTransparencyModifier"):Connect(function()
		SniperH.LocalTransparencyModifier = SniperH.Transparency
	end)
	SniperH.LocalTransparencyModifier = SniperH.Transparency

	SniperH.AccessoryWeld:Destroy()

	if char:FindFirstChildOfClass('Humanoid').RigType == Enum.HumanoidRigType.R6 then
		local att0 = Instance.new("Attachment",SniperH)
		att0.Orientation = Vector3.new(42.52, 92.517, -168.928)
		att0.Position = Vector3.new(0.303, -1.117, -0.134)

		local att1 = Instance.new("Attachment",char["Right Arm"])

		local ap = Instance.new("AlignPosition",SniperH)
		ap.Attachment0 = att0
		ap.Attachment1 = att1
		ap.RigidityEnabled = true 


		local ao = Instance.new("AlignOrientation",SniperH) 
		ao.Attachment0 = att0
		ao.Attachment1 = att1
		ao.RigidityEnabled = true

		local anim = game:GetService("Players").LocalPlayer.Character.Humanoid:LoadAnimation(game:GetService("Players").LocalPlayer.Character.Animate.toolnone.ToolNoneAnim)
		anim:Play()

		local s = Instance.new("Sound", char)
		s.SoundId = "rbxassetid://2426693638"
		s.Volume = 10
		s.Looped = true
		s:Play()

		local e = game:GetService("RunService").Stepped:Connect(function()
			local CurrentLoudness = s.PlaybackLoudness
	        local FOV = 60 + (120 - 60) * (CurrentLoudness / 1200)
	        if FOV >= 60 then
	        	workspace.CurrentCamera.FieldOfView = FOV
	        else
	        	workspace.CurrentCamera.FieldOfView = 60
	        end
		end)
		SniperH.PFXAttachment.Explosion:Destroy()
		SniperH.PFXAttachment.Sparkle:Destroy()
		
		for i,v in pairs(SniperH.PFXAttachment:GetChildren()) do
		   v.Rate = "inf" 
		end

		game:GetService("Players").LocalPlayer.CharacterAdded:Wait()
		e:Disconnect()
		workspace.CurrentCamera.FieldOfView = 70
	end
end